# Lab Design System

One visual design for every CTF / vulnerable-application lab, whatever the vulnerability, the back-end stack or the kind of app (shop, bank, social network, help desk, hospital, food delivery, admin panel, blog...). The layout, components and code are always the same. Only the **theme** (colors + brand name + content) changes per lab.

It describes how a lab **looks and is structured**. It never decides the vulnerability; the lab description does.

Everything is **plain HTML + plain JS + Tailwind CSS v4**. No React, no Next.js, no build step except the Tailwind CSS build.

---

## 1. Hard rules

- The front-end lives in the folder the back-end serves as static files (section 2), so front-end and API share one origin (same `localhost`): no CORS, cookies just work.
- Every page is a real `.html` file with its markup written out. JS never builds a page; it fetches data, fills text with `textContent`, toggles classes and handles forms. Repeated rows use `<template>` tags. Data-driven catalogs (section 7.4) are the only exception.
- All paths in `<link>`, `<script>`, `<a>` and `location` start with `./` (`./src/output.css`, `./js/common.js`, `./login.html`). API calls stay absolute (`/auth/me`).
- No frameworks, no CDN, no Google Fonts, no icon packs, no hot-linked images. Font is Tailwind's default `font-sans`. Icons are small inline SVG (24px viewBox, `stroke="currentColor"`, stroke width 2).
- No comments in code files.
- Light theme only. Use only the theme tokens (section 3) plus Tailwind neutrals.
- Calm layout: few elements per screen (section 9). No sidebars for navigation. Navigation is the top bar and the secondary nav bar.
- The front-end must be **correct and secure by itself**. It never contains the lab's vulnerability, never hints at it, and never adds an accidental one. User-controlled data is inserted with `textContent` or `setAttribute`, never `innerHTML`, unless the lab description explicitly makes that exact spot the vulnerability (section 10).
- Never put the flag, secrets, answers or exploit hints in front-end files.

## 2. Folder structure and back-end stacks

```
<Project>/
  <back-end files>
  package.json            tailwindcss + @tailwindcss/cli v4, script "css"
  <static root>/          ← "wwwroot" for ASP.NET, "public" for Express/Laravel, "static" for Flask/Spring...
    index.html            landing / home of the app
    login.html  register.html          (auth shell)
    <lab pages>.html                   (section 5)
    src/input.css  src/output.css
    js/common.js  js/<page>.js
    img/...
```

Serve the static root from the same server as the API:

| Stack | What to do |
|---|---|
| ASP.NET | `app.UseDefaultFiles(); app.UseStaticFiles();` before `MapControllers()`. Do not use `PublishAot` with MVC. |
| Express | `app.use(express.static("public"))` before the routes. |
| Flask | `Flask(__name__, static_folder="static", static_url_path="")` plus a route returning `static/index.html` for `/`. |
| Django | WhiteNoise or a `static` view; `index.html` served from `/`. |
| Spring Boot | files in `src/main/resources/static`. |
| PHP / Laravel | files in `public`. |
| Go | `http.FileServer(http.Dir("static"))` mounted last. |

Build CSS (rebuild after adding any class):

```
npm install
npx @tailwindcss/cli -i ./<static root>/src/input.css -o ./<static root>/src/output.css --minify
```

If npm is blocked, use the standalone Tailwind v4 binary with the same arguments. Ship the built `output.css`.

## 3. Theme tokens

Token names never change; only values do. The layout uses these names everywhere.

| Role | Token | Used for |
|---|---|---|
| `surface` | header, footer, hero | dark brand band |
| `primary` | secondary nav, headings | dark text/bars |
| `secondary` (+ `-hover`) | links, secondary button | interactive accent |
| `background` | page background | light tint |
| `text-secondary` | body text | |
| `border` | borders | |
| `cta` (+ `-hover`) | primary button, stars, warnings | main call to action |
| `danger` | badges, errors, price drops | |
| Tailwind `green-700` | success text | fixed |
| `#b5c0d1` | footer muted text | fixed |

Cards and panels are always `bg-white`.

### 3.1 Theme presets

Pick the one that fits the lab's app, replace the `@theme` values in `src/input.css`, and set the brand name. Every other value in the file stays.

| Theme | Fits | surface | primary | secondary / hover | background | cta / hover | danger |
|---|---|---|---|---|---|---|---|
| `market` (default) | shop, marketplace, travel | `#101c2b` | `#232f3e` | `#1466d8` / `#0b55bc` | `#eaeded` | `#e67a00` / `#cc6d00` | `#cc0c39` |
| `bank` | bank, wallet, insurance, payments | `#0b2545` | `#13315c` | `#0b6e99` / `#085878` | `#edf1f6` | `#1f7a3d` / `#186330` | `#b42318` |
| `social` | social network, chat, forum, dating | `#1b1f3b` | `#2b2f55` | `#4f46e5` / `#4038c4` | `#f0f1f7` | `#d6336c` / `#b82a5c` | `#c2255c` |
| `desk` | help desk, SaaS, CRM, HR, project tool | `#14213d` | `#1f2a44` | `#2563eb` / `#1d4ed8` | `#f1f5f9` | `#2563eb` / `#1d4ed8` | `#dc2626` |
| `health` | clinic, pharmacy, patient portal | `#0f3d3e` | `#17494a` | `#0e7490` / `#0b5d73` | `#ecf4f3` | `#d97706` / `#b45309` | `#c2410c` |
| `food` | restaurant, delivery, booking | `#1f1a17` | `#3b2a22` | `#b4232f` / `#961c26` | `#f4efec` | `#e23744` / `#c92c39` | `#9f1239` |
| `admin` | admin panel, dev tool, CMS, blog | `#0f172a` | `#1e293b` | `#0f766e` / `#0b5e58` | `#f1f5f4` | `#0f766e` / `#0b5e58` | `#dc2626` |

If the user names a brand look, derive the six values from it and keep contrast (white text must stay readable on `surface`, `secondary` and `cta`).

Brand: plain text logo, `text-2xl font-bold text-white` in the header, plus one inline SVG icon that fits the app (bag, shield, chat bubble, heart, fork, grid). Pick a fictional brand name, never a real company's name or logo.

## 4. `src/input.css` (copy exactly, then change only the `@theme` values)

```css
@import "tailwindcss";

@source not "../js/data.js";

@theme {
    --color-primary: #232f3e;
    --color-secondary: #1466d8;
    --color-secondary-hover: #0b55bc;
    --color-surface: #101c2b;
    --color-background: #eaeded;
    --color-text-primary: #232f3e;
    --color-text-secondary: #424753;
    --color-border: #c7c9ca;
    --color-danger: #cc0c39;
    --color-cta: #e67a00;
    --color-cta-hover: #cc6d00;
}

@layer base {
    h1,
    h2,
    h3 {
        @apply text-primary;
    }
    h1 {
        @apply text-[30px] font-bold;
    }
    h2 {
        @apply text-[26px] font-bold;
    }
    h3 {
        @apply text-[16px] font-medium;
    }
    p {
        @apply text-[14px] text-text-secondary;
    }
    li {
        @apply text-sm;
    }
    main {
        @apply bg-background;
    }
    input:not(input[type="checkbox"]) {
        @apply border border-border p-2 outline-none w-full;
    }
    label {
        @apply block;
    }
    label span {
        @apply mb-1;
    }
    input[type="checkbox"] {
        @apply cursor-pointer;
    }
    input[type="checkbox"] + span {
        @apply ml-2;
    }
}

@layer components {
    .btn {
        @apply border border-border w-full p-2 transition rounded cursor-pointer block text-[16px] text-center;
    }
    .btn-primary {
        @apply bg-cta hover:bg-cta-hover border-none text-white;
    }
    .btn-secondary {
        @apply bg-secondary hover:bg-secondary-hover text-white;
    }
    .link {
        @apply text-secondary text-xs hover:underline;
    }
    .card {
        @apply p-4 rounded bg-white;
    }
    .responsive-flex {
        @apply flex md:flex-row flex-col;
    }
    .section-padding {
        @apply p-4 md:p-6 lg:p-8 space-y-4;
    }
    .grid-4 {
        @apply grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4;
    }
    .grid-3 {
        @apply grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4;
    }
}
```

## 5. Layouts

### 5.1 App shell (every page after the auth pages)

Order inside `<body class="min-h-full flex flex-col">`:

1. `<header class="bg-surface p-4 flex justify-between items-center gap-6 relative h-17.5">` with, in order:
   - mobile hamburger button (`block md:hidden`, `data-menu-open="mobile-sidebar"`)
   - logo link `./index.html`
   - **search slot** (optional): `<form action="./<list>.html" method="get" class="flex-1 flex text-primary">` with `<input name="search" type="search">` and a `btn btn-secondary rounded-none px-3 w-fit` button. Keep it only if the app has something searchable; otherwise use `<div class="flex-1"></div>`. A category `<select name="category">` (`hidden md:block`) only in `market`.
   - **account block**: button `data-menu-open="account-menu"` (`hidden md:flex flex-col items-start text-white text-xs`): `Hello, <span data-user-name>Sign in</span>` and a bold second line (`Accounts & Lists` in `market`, `My Account` elsewhere) with a chevron; followed by the account menu panel.
   - `Submit Flag` text button, `data-flag-open data-in hidden`, `border border-white/60 rounded px-2 py-1 text-white text-xs`
   - **context action** (optional): the cart link in `market`; Balance, Notifications, Inbox or nothing in other themes. At most one.
2. `<nav class="bg-primary text-sm px-4 py-2 relative md:flex gap-4 text-white hidden overflow-auto">`: an `All` button (`data-menu-open="all-menu"`) only when the app has many sections, then 4 to 8 top-level links that match the app (for example Dashboard, Transfers, Cards for a bank).
3. `<div id="banner" class="hidden bg-white border-b-2 border-secondary p-3 text-center font-medium text-primary">Correct! Challenge solved.</div>`
4. Drawers and overlay, all hidden by default: `#mobile-sidebar` (left drawer with the same links as the nav, `md:hidden w-70`), optional `#all-menu`, `#overlay`. The account menu is a drop-down panel inside the header.
5. `<main class="flex flex-col flex-1">` with the page content.
6. Footer (landing page: optional `Back to Top` button + 4 link columns + main footer; every other page: main footer only).
7. The two modals (`#flag-modal`, `#result-modal`, section 6).
8. Scripts: page data scripts first, then `./js/common.js`, then the inline or page script.

Drawer/panel pattern (no custom CSS): every panel has `data-panel`, `data-closed="<classes when closed>"`, `data-opened="<classes when open>"` and starts with the closed classes.

```html
<div id="mobile-sidebar" data-panel data-closed="-translate-x-full" data-opened="translate-x-0"
     class="md:hidden w-70 bg-white fixed h-screen overflow-auto inset-0 z-60 transition-transform duration-300 -translate-x-full">...</div>
<div id="account-menu" data-panel data-closed="-translate-y-full" data-opened="translate-y-0"
     class="bg-white absolute top-0 left-0 w-full z-60 transition ease-out duration-300 -translate-y-full">...</div>
<div id="overlay" class="hidden fixed inset-0 bg-black/20 z-55"></div>
```

Menu rows: `<li><a href class="group p-3 no-underline hover:bg-secondary hover:text-white transition text-text-secondary flex items-center gap-1">icon + label</a></li>`. Menu section title: `<h3 class="p-3 border-b-2 border-border">`.

Account menu content (5 rows at most): section `Accounts` with Login and Register (`data-out hidden`) and Logout (`data-logout data-in hidden`); section `Your Account` with 2 or 3 links to the lab's own pages.

Logged-in/out switching: elements with `data-in` show only when logged in, `data-out` only when logged out. Both start with the `hidden` attribute and `initApp()` flips them.

If the lab has no login at all (for example a public tool), drop the account block and `Submit Flag` moves to a plain header button without `data-in`; call `initApp(false)` and keep the modals.

### 5.2 Auth shell (login, register, and any single-card page such as mail, verify, reset, 2FA, error)

```html
<body class="min-h-full flex flex-col">
  <main class="min-h-screen flex-1 flex flex-col justify-center items-center gap-4 p-2">
    [logo: icon w-12 h-12 + brand text-[30px] font-bold text-primary, link to ./index.html]
    <div class="bg-white shadow-sm p-6 space-y-2 rounded w-full max-w-md">
      <div><h2>Heading</h2><p>Description</p></div>
      [form or content]
    </div>
    [optional outside link line]
  </main>
  [main footer]
</body>
```

The login page may show the lab's demo credentials in a `<code>` line when the lab description gives them. Register: only the fields the back-end needs.

### 5.3 Page patterns

Pages after the shell sit under an optional breadcrumb bar (`<ul class="bg-white px-4 py-1 text-sm flex gap-4 items-center">`, `>` separators), then `<div class="p-4 md:p-6 lg:p-8 space-y-4 flex-1">` holding the blocks below. Pick the patterns the lab needs; reuse them, do not invent new layouts.

| Pattern | Use for | Build |
|---|---|---|
| Landing | home of the app | hero (`bg-surface` band, tag badge, `h1`, one sentence, one button), then 1 to 3 content rows (feature tiles, featured items, deals), then service/feature strip |
| Tile grid | dashboard, categories, quick actions | `.grid-4` or `.grid-3` of `.card` tiles: icon or number, `h3`, one line, one link |
| List / table | orders, tickets, users, transactions, files | `.card overflow-auto` with `table.w-full.text-sm`; header row `text-left text-text-secondary border-b border-border`; rows `border-b border-border`, cells `py-3`; row action is a `.link`. Build rows from a `<template>` |
| Detail | one record (ticket, order, patient, post) | `.card` with `h2`, a 2-column key/value block (`.responsive-flex gap-4`), a sub-list for attachments/comments, action buttons at the bottom |
| Form | create/edit, contact, settings, upload, transfer | one `.card max-w-xl` with labeled inputs and one `btn btn-primary w-fit px-4`; result message line under the button (`showMsg`) |
| Conversation | inbox, chat, comments | `.card` with a message list (each message: name in `font-medium`, text in `p`, time in `text-xs text-text-secondary`) and one input row |
| Profile | account, settings | `.grid-3` of `.card` tiles: identity, status, extras (the flag tile appears only if the lab shows the flag in the app) |
| Catalog | products, menu, doctors, listings | filters + grid (section 7.4) |
| Message page | 404, success, "check your mail" | auth shell card |

Keep to 4 to 8 pages for a typical lab. Every page must have a purpose in the exploit path or make the app feel real; dead links are `#`.

### 5.4 Portal shell (sidebar layout, when the user supplies a reference image or the app is a dashboard)

The default shells above have no sidebar. When the user gives a reference image (or the app is a student/employee/patient portal), follow the image's layout and keep the kit's tokens, components and spacing:

- Authenticated pages: `<div class="flex min-h-screen">` with `<aside id="sidebar" data-panel data-closed="-translate-x-full" data-opened="translate-x-0" class="fixed lg:sticky top-0 left-0 z-60 h-screen w-64 shrink-0 bg-surface text-white flex flex-col gap-6 p-4 transition-transform duration-300 -translate-x-full lg:translate-x-0">` (logo, 5 to 7 nav links, `Logout` button `data-logout` at the bottom; active link `bg-secondary text-white`, others `text-white/75 hover:bg-white/10`) and a right column with a sticky `bg-surface h-16` top bar (hamburger `data-menu-open="sidebar"` below `lg`, search form, `View Source`, `Submit Flag`, bell, initial-circle avatar + name) above the content (`p-4 md:p-6 space-y-4`, white `rounded shadow-sm` cards on the `background` tint). Overlay `#overlay` stays.
- Content blocks from the image: welcome banner (campus/illustration background, dark gradient, `h1` text-white, pill), stat cards (icon tile, label, big number, SVG progress ring), two-column lists, tabbed tables (plain buttons toggling `[data-tabpanel]`), `grid-3` cards, status pills (`bg-green-100 text-green-700`, current `bg-blue-100 text-secondary`).
- Auth pages: full-screen split. Dark campus illustration (`img/campus.svg`, `opacity-80`) with a `bg-linear-to-r from-surface/85 via-surface/50 to-surface/30` overlay; left: crest + brand + tagline (hidden below `lg`); right: glass card `rounded-xl border border-white/15 bg-surface/80 backdrop-blur p-6 md:p-8 text-white` with icon-prefixed inputs (`pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/50`), the primary `btn btn-primary`, an `or` divider and an outline `Back to Homepage` button. Messages inside the dark card go in a white `rounded` box so `showMsg` colors stay readable.
- Public landing: dark header (logo, links, `Student Portal` button), hero with the same illustration, 3 tiles, news list, footer.
- Page scripts call one shared `portalInit()` (`js/portal.js`): reads the session endpoint, redirects to the verify/login page when it fails, fills `[data-fill="field"]`, avatar initials and `[data-user-name]` after `initApp(false)`, and returns the user.
- Use initial-letter circles instead of photos of people. Draw the hero/campus scene as an SVG (no photo downloads).
- Theme: use the preset values from 3.1 (the `desk` preset fits a university) and keep the `cta` of the primary button from the `market` preset (`#e67a00` / `#cc6d00`) when the reference shows an orange primary button.

## 6. Components

- **Buttons**: `.btn` base; `.btn-primary` for the main action; `.btn-secondary` for secondary actions; plain `.btn` white outline for close/cancel. Inline width: add `w-fit px-4`.
- **Inputs**: global style (border, `p-2`, full width). Label: `<label><span>Email</span><input ...></label>`. Textarea/select copy the same classes: `border border-border p-2 outline-none w-full`.
- **Card**: `.card` (`p-4 rounded bg-white`).
- **Badge**: `<span class="inline-block p-1 bg-danger text-xs text-white font-bold">...</span>`; neutral status pill: `inline-block px-2 py-0.5 text-xs rounded bg-background text-text-secondary`; success pill: `bg-green-100 text-green-700`.
- **Messages** (`showMsg`): `text-danger` error, `text-green-700` success, `text-cta` warning, `text-sm`.
- **Price / number**: `font-bold text-primary text-xl`; old price `text-gray-400 line-through`.
- **Rating**: five `text-cta` star SVGs (`w-4 h-4`) and a `text-xs text-secondary` number (catalog themes only).
- **Item card** (catalog): `bg-white p-2 shadow flex flex-col justify-between space-y-2`: image (`w-full rounded-sm aspect-8/5 object-cover`), name link (`line-clamp-2 font-medium hover:text-danger`), rating, price, at most one info line, one full-width button.
- **Feature strip**: white `ul` with 4 items, icon + text, `divide-border`.
- **Modals** (on every shell page): `#flag-modal` with `#flag-form`, `#flag-input` and a submit button plus a close button (`data-modal-close`); `#result-modal` with `#result-title`, `#result-text`, `#result-flag` (hidden) and a close button. Both: `hidden fixed inset-0 z-70 bg-black/40 p-4 items-center justify-center`, inner `bg-white rounded p-6 max-w-md w-full space-y-3`. JS toggles `hidden`/`flex`.
- **Toast** (optional): `fixed top-0 right-0 bg-danger text-white p-10`, slides in with `translate-x-full`.
- **Timer** (optional, landing only): three `inline-flex w-8 h-8 bg-danger text-white rounded` boxes with `data-time` inside `#timer`.

## 7. `js/common.js` (copy exactly)

Change only the values in the `API` object at the top to match the back-end.

```js
var API = {
  me: "/auth/me",
  logout: "/auth/logout",
  flag: "/lab/check-flag",
  login: "./login.html",
  home: "./index.html"
};

var SOLVED_KEY = "lab.solved";

function $(sel, root) {
  return (root || document).querySelector(sel);
}

function $$(sel, root) {
  return Array.prototype.slice.call((root || document).querySelectorAll(sel));
}

async function request(url, opts) {
  var res = await fetch(url, Object.assign({ credentials: "same-origin" }, opts || {}));
  var text = await res.text();
  var data = text;
  try {
    data = JSON.parse(text);
  } catch (e) {}
  return { ok: res.ok, status: res.status, data: data };
}

function postForm(url, fields) {
  return request(url, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(fields)
  });
}

function errorText(r, fallback) {
  if (typeof r.data === "string" && r.data.trim()) return r.data;
  return fallback || "Something went wrong.";
}

function showMsg(el, text, kind) {
  var colors = { error: "text-danger", ok: "text-green-700", warn: "text-cta" };
  el.className = "text-sm " + (colors[kind] || "text-text-secondary");
  el.textContent = text;
}

function storeGet(key) {
  try {
    return localStorage.getItem(key);
  } catch (e) {
    return null;
  }
}

function storeSet(key, value) {
  try {
    localStorage.setItem(key, value);
  } catch (e) {}
}

function setPanel(el, open) {
  var closed = (el.dataset.closed || "").split(" ").filter(Boolean);
  var opened = (el.dataset.opened || "").split(" ").filter(Boolean);
  closed.forEach(function (c) {
    el.classList.toggle(c, !open);
  });
  opened.forEach(function (c) {
    el.classList.toggle(c, open);
  });
}

function closeMenus() {
  $$("[data-panel]").forEach(function (p) {
    setPanel(p, false);
  });
  var overlay = $("#overlay");
  if (overlay) overlay.classList.add("hidden");
}

function openMenu(id) {
  closeMenus();
  var panel = $("#" + id);
  if (!panel) return;
  setPanel(panel, true);
  var overlay = $("#overlay");
  if (overlay) overlay.classList.remove("hidden");
}

function showModal(id) {
  var m = $("#" + id);
  m.classList.remove("hidden");
  m.classList.add("flex");
}

function hideModals() {
  ["flag-modal", "result-modal"].forEach(function (id) {
    var m = $("#" + id);
    if (!m) return;
    m.classList.add("hidden");
    m.classList.remove("flex");
  });
}

function startCountdown() {
  var box = $("#timer");
  if (!box) return;

  function tick() {
    var end = new Date();
    end.setHours(23, 59, 59, 0);
    var diff = Math.max(0, Math.floor((end.getTime() - Date.now()) / 1000));
    var parts = [Math.floor(diff / 3600), Math.floor(diff / 60) % 60, diff % 60];
    $$("[data-time]", box).forEach(function (el, i) {
      el.textContent = String(parts[i]).padStart(2, "0");
    });
  }

  tick();
  setInterval(tick, 1000);
}

function wireShell() {
  document.addEventListener("click", function (e) {
    var open = e.target.closest("[data-menu-open]");
    if (open) {
      openMenu(open.dataset.menuOpen);
      return;
    }
    if (e.target.closest("[data-menu-close]") || e.target.id === "overlay") closeMenus();

    if (e.target.closest("[data-top]")) window.scrollTo({ top: 0, behavior: "smooth" });
  });

  startCountdown();
}

async function initApp(required) {
  wireShell();

  var r = await request(API.me);
  var me = r.ok ? r.data : null;

  if (!me && required) {
    location.replace(API.login);
    return null;
  }

  $$("[data-in]").forEach(function (el) {
    el.hidden = !me;
  });
  $$("[data-out]").forEach(function (el) {
    el.hidden = !!me;
  });

  if (!me) return null;

  $$("[data-user-name]").forEach(function (el) {
    el.textContent = me.name || me.username || me.email;
  });

  var banner = $("#banner");
  if (banner && storeGet(SOLVED_KEY) === "1") banner.classList.remove("hidden");

  $$("[data-logout]").forEach(function (b) {
    b.addEventListener("click", async function () {
      await request(API.logout, { method: "POST" });
      location.href = API.home;
    });
  });

  $$("[data-flag-open]").forEach(function (b) {
    b.addEventListener("click", function () {
      closeMenus();
      $("#flag-input").value = "";
      showModal("flag-modal");
      $("#flag-input").focus();
    });
  });

  $$("[data-modal-close]").forEach(function (b) {
    b.addEventListener("click", hideModals);
  });

  ["flag-modal", "result-modal"].forEach(function (id) {
    var m = $("#" + id);
    if (!m) return;
    m.addEventListener("click", function (e) {
      if (e.target === m) hideModals();
    });
  });

  $("#flag-form").addEventListener("submit", async function (e) {
    e.preventDefault();
    var value = $("#flag-input").value.trim();
    var r2 = await postForm(API.flag, { flag: value });
    var solved = r2.ok && r2.data && r2.data.solved === true;

    var title = $("#result-title");
    var flag = $("#result-flag");

    title.textContent = solved ? "Flag accepted" : "Not solved yet";
    title.className = "text-xl font-bold " + (solved ? "text-green-700" : "text-cta");
    $("#result-text").textContent = solved ? "Challenge solved." : "That is not the flag. Keep looking.";

    if (solved) {
      storeSet(SOLVED_KEY, "1");
      if (banner) banner.classList.remove("hidden");
      flag.textContent = value;
      flag.classList.remove("hidden");
    } else {
      flag.classList.add("hidden");
    }

    hideModals();
    showModal("result-modal");
  });

  return me;
}
```

### 7.1 Contract used by pages

`initApp(true)` on pages that need a login (redirects to `API.login`), `initApp(false)` on public pages. It fills `[data-user-name]`, flips `[data-in]/[data-out]`, wires `[data-logout]`, `[data-flag-open]`, `[data-modal-close]`, menus (`[data-menu-open]`, `[data-menu-close]`, `#overlay`), `[data-top]` and the countdown. It resolves to the user object or `null`. Every shell page contains the two modals and the `#banner`.

### 7.2 Page scripts

Page scripts are small plain functions: read the query string with `URLSearchParams`, call `request()`, fill the DOM with `textContent`, show errors with `showMsg(el, errorText(r, "fallback"), "error")`. Clone `<template>` content for rows. IDs from the URL are passed to the API untouched (the lab may depend on that).

### 7.3 Sessions and tokens

Default is a cookie session set by the back-end (`credentials: "same-origin"` is already in `request`). If the lab description uses a JWT or API token, follow it exactly (where it is stored, which header carries it) and keep that logic in one function in `common.js` (`request` adds the header). Do not invent extra auth.

### 7.4 Catalog pages (optional)

For shop-like labs with many items, the list is data-driven from a local `js/data.js` (or the API) and `js/<list>.js` filters client-side: filters (department, brand, rating, price, hide out-of-stock) and sort read and write the URL query with `history.replaceState`; the header search form uses the same parameter names; 12 items per page with a pagination bar; the page shows breadcrumb, a white results header (title, result count, sort select) and the `grid-4`. `data.js` is excluded from Tailwind scanning (`@source not "../js/data.js";`). Filters are a white `w-60` aside on desktop and a drawer opened by a `Filter` button on mobile. A catalog is only added when the lab's story needs it.

## 8. Images

No hot-linking and no CDN. In order of preference:

0. **The kit's own `assets/` folder** (shipped with this document as `design-kit.zip`: `assets/photo`, `assets/deals`, `assets/hero.png`, `assets/svg`, listed in `assets/README.md`). Copy what the lab needs into `img/`. If a needed picture is missing, use options 1 to 3.
1. **Photos the user supplies** (an images zip). Resize with PIL to 480px wide JPG quality 82 (hero 840px wide PNG); never ship the originals. Put them in `img/photo/`, `img/deals/`, `img/hero.png`. Map each photo only to content it honestly shows. Anything without a matching photo falls back to a motif.
2. **Generated SVG motifs** (`motifs.js`, if the user attaches it, or drawn in the same flat style): 320x200 tile with a light gradient, a white circle, a soft ground shadow and one centered flat object in the theme colors. Write one file per item (`img/p/<id>.svg`).
3. **No image at all**: most lab pages (tables, forms, details) need none. Use an icon in a `bg-background rounded` square instead of a picture.

Always `<img src alt loading="lazy" class="w-full rounded-sm aspect-8/5 object-cover">`. Do not download or embed pictures of real people. A test server must send `image/svg+xml`, `image/jpeg` and `image/png`.

## 9. Keep it calm (noise rules)

- Header: logo, optional search, account block, optional one context action, Submit Flag when logged in. Nothing else.
- Account menu: 2 sections, 5 rows at most.
- Landing: hero, 1 to 3 content rows, feature strip. Footer: 4 columns with 3 links, bottom row with 4 links.
- Cards: one status/info line, one main action.
- Tables: 3 to 6 columns.
- One color of emphasis per screen: `cta` for the main action, `danger` only for problems and price drops.
- No marquee text, no pop-ups on load, no cookie banners, no chat widgets, no ads.

## 10. Vulnerability-neutral front-end

The back-end holds the vulnerability. The front-end shows the normal, honest UI so the player finds the bug by testing, not by reading hints.

- Expose what a real app exposes: record IDs in URLs and links (`ticket.html?id=2`), download links, a search box, a profile field. Do not add `hint`, `TODO`, `debug`, hidden fields, console logs or comments about the bug.
- Do not add protections the lab is about to be tested on (client-side ownership checks, token checks, validation that blocks the exploit). Client-side validation is limited to required fields.
- Keep exploit inputs workable: do not strip or encode what the player types before it is sent, unless the lab says so.
- Output encoding: always `textContent`. Only when the lab is a stored/reflected XSS or HTML-injection lab, the one specific sink the description names (for example the comment body) may use `innerHTML`, in one place, and nowhere else.

Typical surfaces per vulnerability class (use what the lab description needs, nothing more):

| Class | Surface to provide |
|---|---|
| IDOR / broken access control | list and detail pages with IDs in the URL, download/export links, profile and settings pages |
| Account takeover / auth bypass | login, register, verify, reset, mailbox pages; a demo mailbox when the app "sends" mail |
| SQL injection | search box, filter, login form, sort parameter |
| XSS (stored/reflected/DOM) | comment, review, message, profile-bio and search-result pages |
| CSRF | state-changing forms (change email, transfer) on the profile pages |
| SSRF | an "import from URL", preview, webhook or avatar-URL form |
| File upload / path traversal | upload form, file list, download link with a filename parameter |
| Business logic | cart/checkout, coupon, transfer, quota, rating forms that show server messages |
| JWT / session flaws | normal login; the token handling follows 7.3 |
| Open redirect | a `?next=` / `?redirect=` parameter on login or logout links |
| API / mass assignment | edit-profile and create forms posting normal fields |

## 11. Lab chrome

- `Submit Flag` (header, logged-in) opens `#flag-modal`; the page posts the flag to `API.flag` (form field `flag`, JSON reply `{solved: true|false}`); the flag is never stored or compared in front-end code. A correct flag opens the result modal, shows the banner and remembers it in `localStorage` (inside try/catch).
- Never drop the search bar or the `All` menu from the `market` shell: they are part of the shell. Pages they point to must exist (catalog) or the controls must stay inert.
- If the back-end has no flag endpoint, add one in its own stack (compare with a flag from configuration), and report that you added it.
- The footer carries one small line: "Training lab environment. No real transactions are processed." (adjust the noun to the app).
- Where the lab description says the flag appears in the app (for example on the victim's account page), show it as normal data from the API; nowhere else.

### 11.1 View Source button (optional whitebox)

When the user wants players to read the back-end code, add a `View Source` button. Default is off.

- Header: a bordered text button `data-source-open` next to `Submit Flag` (visible when logged out too, `hidden md:block`), plus a `View Source` row in the account menu / mobile drawer, and a `link` button "View backend source" under the card on auth-shell pages.
- Modal `#source-modal` on every page (same overlay style as the flag modal): header with `Backend source` and a `data-source-close` button, one sentence, a `#source-tabs` row, then a scrollable `bg-background text-xs font-mono` box holding two `<pre>`: `#source-gutter` (line numbers, `text-gray-400 select-none`) and `#source-code`.
- Files are static copies in `<static root>/source/<Name>.txt`. The `.txt` extension is required (static servers refuse unknown types like `.cs`). Show only the files that matter for the exploit path (controllers, session/auth data, `Program`), never the flag-check endpoint.
- Copies are generated by `sync-source.js` (below), which strips a BOM, deletes any line containing "Intentionally vulnerable", and replaces every flag literal with `LAB{...}`. Review every copy so no comment, name or text points at the bug and no flag or secret is shown. Re-run the script after every back-end change.
- Tabs and viewer logic are `js/source.js`; all text goes in with `textContent`.

`js/source.js` (edit only `SOURCE_FILES`):

```js
var SOURCE_FILES = [
  { name: "AuthController.cs", url: "./source/AuthController.cs.txt" },
  { name: "AccountController.cs", url: "./source/AccountController.cs.txt" },
  { name: "InboxController.cs", url: "./source/InboxController.cs.txt" },
  { name: "SessionData.cs", url: "./source/SessionData.cs.txt" },
  { name: "Program.cs", url: "./source/Program.cs.txt" }
];

(function () {
  var modal = document.getElementById("source-modal");
  if (!modal) return;

  var tabs = document.getElementById("source-tabs");
  var code = document.getElementById("source-code");
  var gutter = document.getElementById("source-gutter");
  var cache = {};
  var buttons = [];

  function setActive(index) {
    buttons.forEach(function (b, i) {
      b.className = "btn w-fit px-3 py-1 text-sm " + (i === index ? "btn-secondary" : "");
    });
  }

  async function show(index) {
    var file = SOURCE_FILES[index];
    setActive(index);

    if (cache[file.url] === undefined) {
      code.textContent = "Loading...";
      gutter.textContent = "";
      try {
        var res = await fetch(file.url);
        cache[file.url] = res.ok ? await res.text() : "Could not load " + file.name + ".";
      } catch (e) {
        cache[file.url] = "Could not load " + file.name + ".";
      }
    }

    var text = cache[file.url];
    var count = text.split("\n").length;
    var numbers = [];
    for (var i = 1; i <= count; i++) numbers.push(i);

    code.textContent = text;
    gutter.textContent = numbers.join("\n");
  }

  SOURCE_FILES.forEach(function (file, i) {
    var b = document.createElement("button");
    b.type = "button";
    b.textContent = file.name;
    b.addEventListener("click", function () {
      show(i);
    });
    tabs.appendChild(b);
    buttons.push(b);
  });

  function open() {
    modal.classList.remove("hidden");
    modal.classList.add("flex");
    show(0);
  }

  function close() {
    modal.classList.add("hidden");
    modal.classList.remove("flex");
  }

  document.addEventListener("click", function (e) {
    if (e.target.closest("[data-source-open]")) {
      if (typeof closeMenus === "function") closeMenus();
      open();
      return;
    }
    if (e.target.closest("[data-source-close]") || e.target === modal) close();
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") close();
  });
})();
```

`sync-source.js` (project root; edit only the `files` list; run `node sync-source.js`):

```js
const fs = require("fs");
const path = require("path");

const root = __dirname;
const out = path.join(root, "wwwroot", "source");

const files = [
  ["controrllers/Authcontroller.cs", "AuthController.cs"],
  ["controrllers/Accountcontroller.cs", "AccountController.cs"],
  ["controrllers/Inboxcontroller.cs", "InboxController.cs"],
  ["data/sessiondata.cs", "SessionData.cs"],
  ["Program.cs", "Program.cs"]
];

fs.mkdirSync(out, { recursive: true });

files.forEach(function (pair) {
  var text = fs.readFileSync(path.join(root, pair[0]), "utf8").replace(/^﻿/, "").replace(/\r\n/g, "\n");
  text = text
    .split("\n")
    .filter(function (line) {
      return !/Intentionally vulnerable/i.test(line);
    })
    .join("\n")
    .replace(/LAB\{[^}]*\}/g, "LAB{...}");
  fs.writeFileSync(path.join(out, pair[1] + ".txt"), text);
});

console.log("source files written to wwwroot/source");
```

## 12. Back-end contract

Adapt to the lab's real endpoints, keep the shapes. JSON is whatever the back-end uses (camelCase preferred), errors are plain text with a 4xx status. The shared shell needs only these three:

| Call | Notes |
|---|---|
| `GET /auth/me` (`API.me`) | `{name, ...}` for the logged-in user; 401 when logged out |
| `POST /auth/logout` (`API.logout`) | ends the session |
| `POST /lab/check-flag` (`API.flag`, form `flag`) | `{solved, message}` |

Typical extras (only if the lab uses them): `POST /auth/login` (form fields), `POST /auth/register`, `GET /auth/test-mail` (demo mailbox), `GET /auth/verify?...`, and the lab's own resource endpoints (`/tickets`, `/orders`, `/files/{id}`...). Read the back-end source and use the real routes and field names; do not rename them.

## 13. Back-end audit rules

- The supplied back-end may be the fixed version, a skeleton, or a different stack. Compare it with the lab description line by line.
- If it lacks the described vulnerability, change only what is needed to match the description, and list each change (file, before, after).
- Keep seed data exactly as the description says (accounts, records, tokens, flag).
- Do not add rate limits, extra checks or hardening the description does not mention. If you notice an unintended shortcut that bypasses the intended path, report it instead of silently fixing it.
- Make sure the static root is served and the app starts (section 2).

## 14. Checklist before delivering

1. Every page opens with `./` paths and has no console errors (desktop and 390px wide).
2. Header switches between "Hello, Sign in" and "Hello, <name>" and shows Logout and Submit Flag only when logged in.
3. The full solve path from the lab description works in a real browser against the back-end (or a mock that mirrors it), and the flag is accepted.
4. Images load; nothing hot-linked.
5. CSS rebuilt: `output.css` contains every class used.
6. No comments, hints or flag in front-end files.
7. A short solve walkthrough, the bug location, how it matches or differs from the description, the fix, and a list of anything to check by hand are given to the lab author. If .NET/Node/Python could not be run, say the back-end was not compiled or started.
