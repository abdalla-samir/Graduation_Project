# Kit assets

Ready-to-use images. Copy what the lab needs into the project's `img/` folder; do not hot-link.

## photo/ (480px wide JPG)

building-sets.jpg, dining.jpg, dresses.jpg, electronics-accessories.jpg, fashion-accessories.jpg, fragrance.jpg, furniture.jpg, games.jpg, gaming-chair.jpg, gaming-figure.jpg, hair-care.jpg, headset.jpg, health-beauty.jpg, home-decor.jpg, home.jpg, jeans.jpg, keyboard.jpg, kitchen.jpg, laptop.jpg, makeup.jpg, men-fashion.jpg, monitor.jpg, mouse.jpg, phones.jpg, pulsh-toys.jpg, shoes-1.jpg, shoes-2.jpg, skin-care.jpg, storage.jpg, tops.jpg, women-fashion.jpg

Topics: laptop, monitor, phones, keyboard, mouse, headset, gaming-chair, gaming-figure, games, building-sets, pulsh-toys, jeans, tops, dresses, shoes-1, shoes-2, men-fashion, women-fashion, fashion-accessories, kitchen, dining, home, home-decor, furniture, storage, skin-care, makeup, hair-care, fragrance, health-beauty, electronics-accessories.

## deals/ (480px wide JPG)

espresso.jpg, headset.jpg, toothbrush.jpg, vacuum.jpg, watch.jpg, water-bottle.jpg

## hero.png

840px wide hero picture (laptop, phone, headphones, earbuds, watch) for dark `surface` hero bands.

## svg/ (320x200 flat motifs, default palette)

abc.svg, babybottle.svg, backpack.svg, bag.svg, basketball.svg, bath.svg, bed.svg, bike.svg, blender.svg, blocks.svg, box.svg, brush.svg, bulb.svg, cable.svg, camera.svg, case.svg, chair.svg, chip.svg, console.svg, controller.svg, desktop.svg, dining.svg, doll.svg, dress.svg, drive.svg, dumbbell.svg, earbuds.svg, espresso.svg, figure.svg, football.svg, fragrance.svg, gamingheadset.svg, gamingmonitor.svg, haircare.svg, headphones.svg, jeans.svg, keyboard.svg, kidsshirt.svg, lamp.svg, laptop.svg, lipstick.svg, monitor.svg, mouse.svg, phone.svg, pot.svg, powerbank.svg, printer.svg, razor.svg, ring.svg, screenprot.svg, shirt.svg, shoe.svg, skincare.svg, sofa.svg, speaker.svg, sunglasses.svg, tablet.svg, teddy.svg, tent.svg, toothbrush.svg, tv.svg, vacuum.svg, vase.svg, videogame.svg, watch.svg, waterbottle.svg, wristwatch.svg

For other palettes or the 5 variants run `node motifs.js <outDir>` or `kit.render(name, paletteIndex)`.

## Rules

- Use photos first, an SVG motif when no photo matches, an icon tile when no picture is needed.
- Copy only the files used; keep names.
- Add new pictures here in the same sizes when the kit grows.
