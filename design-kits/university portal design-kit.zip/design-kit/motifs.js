const PALETTES = [
  { m: "#232f3e", l: "#c9d3de", a: "#e67a00", bg: "#f3f4f6" },
  { m: "#1466d8", l: "#cfe0fa", a: "#232f3e", bg: "#eef3fb" },
  { m: "#3f4a5a", l: "#dfe3e8", a: "#cc0c39", bg: "#f5f3f3" },
  { m: "#232f3e", l: "#cfe0fa", a: "#1466d8", bg: "#eff3f8" },
  { m: "#e67a00", l: "#fbe3c2", a: "#232f3e", bg: "#faf5ee" }
];

const W = "#ffffff";
const G = "#9aa5b1";
const D = "#101c2b";

const r = (x, y, w, h, rx, fill, extra) =>
  `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx || 0}" fill="${fill}"${extra ? " " + extra : ""}/>`;
const c = (x, y, rad, fill, extra) =>
  `<circle cx="${x}" cy="${y}" r="${rad}" fill="${fill}"${extra ? " " + extra : ""}/>`;
const e = (x, y, rx, ry, fill, extra) =>
  `<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="${fill}"${extra ? " " + extra : ""}/>`;
const p = (d, fill, extra) => `<path d="${d}" fill="${fill}"${extra ? " " + extra : ""}/>`;
const s = (d, stroke, w, extra) =>
  `<path d="${d}" fill="none" stroke="${stroke}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"${extra ? " " + extra : ""}/>`;

const wave = (x, y, w, h, a) =>
  p(`M${x} ${y + h} L${x + w * 0.35} ${y + h * 0.35} L${x + w * 0.6} ${y + h * 0.7} L${x + w * 0.8} ${y + h * 0.45} L${x + w} ${y + h} Z`, a, 'opacity=".4"');

function keys(x, y, cols, rows, kw, kh, gap, fill) {
  let out = "";
  for (let j = 0; j < rows; j++)
    for (let i = 0; i < cols; i++) out += r(x + i * (kw + gap), y + j * (kh + gap), kw, kh, 2, fill);
  return out;
}

const M = {
  headphones: (k) =>
    s("M50 112 V96 a50 50 0 0 1 100 0 V112", k.m, 10) +
    r(36, 102, 28, 46, 13, k.m) + r(136, 102, 28, 46, 13, k.m) +
    r(43, 112, 9, 26, 4, k.a) + r(148, 112, 9, 26, 4, k.a),
  earbuds: (k) =>
    r(50, 100, 100, 60, 28, k.m) + s("M50 122 H150", k.l, 3) + c(100, 142, 4, k.a) +
    e(78, 74, 13, 17, k.l) + r(86, 82, 6, 22, 3, k.l) + e(122, 74, 13, 17, k.l) + r(108, 82, 6, 22, 3, k.l),
  camera: (k) =>
    r(38, 70, 124, 84, 10, k.m) + r(68, 58, 38, 16, 4, k.m) + c(100, 112, 30, k.l) + c(100, 112, 21, D) + c(100, 112, 8, k.a) + r(136, 78, 16, 8, 2, k.a),
  tv: (k) =>
    r(28, 46, 144, 94, 6, k.m) + r(34, 52, 132, 82, 3, k.l) + wave(34, 70, 132, 64, k.a) + r(88, 140, 24, 10, 2, k.m) + r(66, 150, 68, 6, 3, k.m),
  speaker: (k) =>
    r(64, 36, 72, 128, 14, k.m) + c(100, 72, 15, k.l) + c(100, 72, 6, D) + c(100, 124, 28, k.l) + c(100, 124, 15, D) + c(100, 124, 5, k.a),
  watch: (k) =>
    r(78, 26, 44, 52, 8, k.l) + r(78, 122, 44, 52, 8, k.l) + r(62, 62, 76, 76, 20, k.m) + r(70, 70, 60, 60, 14, D) +
    c(100, 100, 17, "none", `stroke="${k.a}" stroke-width="5"`) + r(138, 92, 6, 16, 3, k.m),
  bulb: (k) =>
    c(100, 84, 38, k.l) + r(82, 116, 36, 10, 3, k.m) + r(84, 128, 32, 10, 3, k.m) + r(92, 140, 16, 9, 4, k.m) +
    s("M88 104 L94 82 L100 98 L106 82 L112 104", k.a, 4),
  cable: (k) =>
    s("M30 100 C8 100 8 152 60 152 L140 152 C190 152 190 62 150 62", k.m, 6) +
    r(24, 86, 34, 28, 5, k.m) + r(58, 91, 12, 6, 2, G) + r(58, 103, 12, 6, 2, G) +
    r(136, 48, 44, 28, 7, k.m) + r(146, 57, 24, 10, 3, k.a),
  laptop: (k) =>
    r(46, 50, 108, 74, 6, k.m) + r(52, 56, 96, 62, 3, k.l) + wave(52, 74, 96, 44, k.a) +
    p("M28 128 H172 L165 144 H35 Z", k.m) + r(88, 128, 24, 4, 2, k.l),
  desktop: (k) =>
    r(38, 38, 52, 124, 6, k.m) + c(64, 58, 5, k.a) + s("M50 82 H78 M50 92 H78 M50 102 H78", k.l, 3) +
    r(100, 60, 72, 50, 4, k.m) + r(105, 65, 62, 40, 2, k.l) + r(131, 110, 10, 16, 2, k.m) + r(118, 126, 36, 5, 2, k.m),
  monitor: (k) =>
    r(30, 46, 140, 90, 6, k.m) + r(36, 52, 128, 76, 3, k.l) + wave(36, 70, 128, 58, k.a) + r(92, 136, 16, 18, 2, k.m) + r(72, 154, 56, 6, 3, k.m),
  keyboard: (k) =>
    r(24, 74, 152, 62, 8, k.m) + keys(32, 82, 10, 1, 11, 10, 3, k.l) + keys(32, 96, 10, 1, 11, 10, 3, k.l) +
    r(32, 110, 24, 10, 2, k.l) + r(58, 110, 70, 10, 2, k.l) + r(130, 110, 38, 10, 2, k.a),
  mouse: (k) =>
    r(66, 46, 68, 108, 34, k.m) + s("M100 46 V94 M66 94 H134", k.l, 3) + r(96, 62, 8, 18, 4, k.a),
  chip: (k) =>
    s("M72 52 V64 M88 52 V64 M104 52 V64 M120 52 V64 M72 136 V148 M88 136 V148 M104 136 V148 M120 136 V148 M52 72 H64 M52 88 H64 M52 104 H64 M52 120 H64 M136 72 H148 M136 88 H148 M136 104 H148 M136 120 H148", G, 5) +
    r(62, 62, 76, 76, 8, k.m) + r(78, 78, 44, 44, 4, k.l) + c(100, 100, 7, k.a),
  drive: (k) =>
    r(36, 78, 128, 54, 8, k.m) + r(48, 90, 64, 7, 3, k.l) + r(48, 106, 40, 5, 2, G) + c(144, 105, 6, k.a),
  printer: (k) =>
    r(62, 44, 76, 46, 3, W, `stroke="${G}" stroke-width="3"`) + s("M72 58 H128 M72 68 H116", G, 3) +
    r(36, 86, 128, 58, 9, k.m) + r(60, 126, 80, 28, 3, W, `stroke="${G}" stroke-width="3"`) + c(146, 102, 5, k.a),
  phone: (k) =>
    r(64, 28, 72, 144, 14, k.m) + r(70, 38, 60, 124, 8, k.l) + wave(70, 100, 60, 62, k.a) + r(90, 42, 20, 5, 2.5, k.m) + r(90, 152, 20, 3, 1.5, k.m),
  tablet: (k) =>
    r(38, 42, 124, 116, 10, k.m) + r(46, 50, 108, 100, 4, k.l) + wave(46, 86, 108, 64, k.a) + c(42, 100, 2, k.l),
  case: (k) =>
    r(58, 26, 84, 148, 18, k.a) + r(68, 36, 64, 128, 12, k.l) + r(72, 40, 26, 26, 7, k.m) + c(80, 50, 4, k.l) + c(90, 58, 4, k.l),
  powerbank: (k) =>
    r(54, 46, 92, 108, 12, k.m) + r(88, 54, 24, 6, 2, G) + r(68, 128, 12, 6, 2, k.a) + r(86, 128, 12, 6, 2, k.a) + r(104, 128, 12, 6, 2, k.a) +
    p("M104 72 L90 100 H102 L97 122 L114 92 H102 Z", k.l),
  screenprot: (k) =>
    r(64, 28, 72, 144, 14, k.m) + r(70, 38, 60, 124, 8, k.l) + p("M70 120 L130 60 V82 L70 142Z", W, 'opacity=".7"') + p("M70 150 L130 100 V110 L78 160Z", W, 'opacity=".5"') + r(90, 42, 20, 5, 2.5, k.m),
  shirt: (k) =>
    p("M70 40 L38 62 L54 88 L70 80 V162 H130 V80 L146 88 L162 62 L130 40 C122 54 78 54 70 40Z", k.m) +
    s("M78 42 C84 58 116 58 122 42", k.l, 4) + r(108, 98, 16, 16, 3, k.a),
  kidsshirt: (k) =>
    `<g transform="translate(20 22) scale(.8)">` + M.shirt(k) + `</g>` + c(100, 108, 9, k.l),
  dress: (k) =>
    p("M82 34 H118 L124 72 L148 166 H52 L76 72 Z", k.m) + s("M76 78 H124", k.a, 8) + s("M88 34 V22 M112 34 V22", k.m, 4),
  jeans: (k) =>
    p("M64 34 H136 L144 166 H108 L100 94 L92 166 H56 Z", k.m) + r(64, 34, 72, 12, 2, k.l, 'opacity=".5"') + s("M100 46 V94", k.a, 2, 'stroke-dasharray="4 3"') + c(100, 54, 3, k.a),
  shoe: (k) =>
    p("M28 132 V98 C28 90 36 86 44 88 L64 94 C74 80 90 66 112 64 L120 76 C130 92 160 100 172 114 C176 120 176 130 172 134 H28 Z", k.m) +
    r(24, 134, 154, 14, 7, k.l) + s("M86 78 L98 90 M96 72 L108 84 M106 68 L118 80", k.l, 3) + p("M44 118 C80 128 130 124 168 112 C168 120 168 128 166 130 H44Z", k.a, 'opacity=".9"'),
  bag: (k) =>
    s("M76 78 V66 a24 24 0 0 1 48 0 V78", k.m, 8) + r(44, 76, 112, 84, 12, k.m) + s("M44 100 H156", k.l, 3) + r(91, 94, 18, 16, 3, k.a),
  wristwatch: (k) =>
    r(84, 22, 32, 56, 8, k.m) + r(84, 122, 32, 56, 8, k.m) + c(100, 100, 42, k.l, `stroke="${k.m}" stroke-width="6"`) + c(100, 100, 32, W) +
    s("M100 100 V78 M100 100 L117 108", k.m, 4) + c(100, 100, 4, k.a) + r(142, 95, 8, 10, 3, k.m),
  ring: (k) =>
    c(100, 116, 36, "none", `stroke="${k.a}" stroke-width="12"`) + p("M100 50 L118 66 L100 84 L82 66Z", k.l, `stroke="${k.m}" stroke-width="3"`),
  sunglasses: (k) =>
    e(66, 100, 29, 21, k.m) + e(134, 100, 29, 21, k.m) + s("M94 96 Q100 88 106 96", k.m, 5) + s("M38 94 L22 86 M162 94 L178 86", k.m, 5) + e(58, 92, 8, 5, k.l, 'opacity=".5"') + e(126, 92, 8, 5, k.l, 'opacity=".5"'),
  sofa: (k) =>
    r(40, 66, 120, 52, 14, k.m) + r(30, 96, 140, 48, 12, k.m) + r(24, 84, 26, 64, 11, k.m) + r(150, 84, 26, 64, 11, k.m) + s("M100 100 V138", k.l, 3) +
    r(58, 90, 26, 26, 6, k.a, 'transform="rotate(-8 71 103)"') + r(40, 146, 8, 14, 2, G) + r(152, 146, 8, 14, 2, G),
  vase: (k) =>
    s("M100 44 L90 16 M100 44 L110 12 M100 44 L124 24", k.l, 3) + c(90, 16, 6, k.a) + c(110, 12, 6, k.a) + c(124, 24, 6, k.a) +
    p("M82 44 H118 C116 64 136 76 136 110 C136 142 120 164 100 164 C80 164 64 142 64 110 C64 76 84 64 82 44Z", k.m) + s("M68 112 H132", k.a, 6),
  pot: (k) =>
    r(48, 88, 104, 62, 10, k.m) + r(44, 76, 112, 14, 7, k.l) + r(92, 62, 16, 12, 5, k.a) + r(28, 100, 20, 10, 5, k.m) + r(152, 100, 20, 10, 5, k.m),
  bed: (k) =>
    r(30, 56, 16, 104, 4, k.m) + r(30, 110, 142, 34, 8, k.l) + r(70, 104, 102, 40, 8, k.a) + r(48, 90, 36, 20, 9, W, `stroke="${G}" stroke-width="2"`) + r(30, 146, 10, 14, 2, k.m) + r(162, 146, 10, 14, 2, k.m),
  bath: (k) =>
    r(48, 54, 104, 28, 7, k.a) + r(44, 86, 112, 28, 7, k.l) + r(48, 118, 104, 28, 7, k.m) + s("M60 60 V76 M72 60 V76 M128 124 V140 M140 124 V140", W, 3),
  lamp: (k) =>
    p("M68 46 H132 L148 102 H52 Z", k.a) + r(96, 102, 8, 50, 2, k.m) + r(68, 152, 64, 10, 5, k.m),
  box: (k) =>
    r(42, 72, 116, 76, 6, k.l, `stroke="${k.m}" stroke-width="5"`) + s("M42 96 H158 M42 120 H158", k.m, 3) + r(86, 82, 28, 8, 4, k.m) + r(76, 126, 48, 16, 3, k.a),
  blender: (k) =>
    p("M72 46 H128 L120 118 H80 Z", k.l, `stroke="${k.m}" stroke-width="4"`) + p("M76 84 H124 L120 118 H80Z", k.a, 'opacity=".5"') + r(66, 36, 68, 12, 4, k.m) + r(68, 118, 64, 42, 8, k.m) + c(100, 140, 8, k.a),
  skincare: (k) =>
    r(92, 36, 16, 26, 4, k.m) + r(92, 36, 34, 8, 4, k.m) + r(72, 64, 56, 98, 14, k.l, `stroke="${k.m}" stroke-width="4"`) + r(80, 100, 40, 34, 5, k.a),
  haircare: (k) =>
    r(84, 36, 32, 26, 6, k.a) + r(70, 60, 60, 104, 14, k.m) + r(78, 96, 44, 44, 6, k.l),
  fragrance: (k) =>
    r(88, 44, 24, 30, 4, k.m) + r(94, 72, 12, 10, 2, k.m) + r(58, 80, 84, 80, 12, k.l, `stroke="${k.m}" stroke-width="4"`) + r(78, 104, 44, 30, 4, k.a),
  lipstick: (k) =>
    r(74, 112, 52, 50, 6, k.m) + r(78, 92, 44, 20, 3, k.l) + p("M84 92 V62 L100 38 L116 62 V92Z", k.a),
  razor: (k) =>
    r(93, 80, 14, 82, 7, k.m) + r(62, 46, 76, 36, 9, k.l, `stroke="${k.m}" stroke-width="4"`) + s("M74 58 H126 M74 68 H126", k.m, 3) + r(93, 112, 14, 18, 3, k.a),
  brush: (k) =>
    r(93, 94, 14, 68, 7, k.m) + r(88, 72, 24, 24, 4, k.l) + p("M86 72 C84 48 100 34 100 34 C100 34 116 48 114 72Z", k.a),
  toothbrush: (k) =>
    `<g transform="rotate(35 100 100)">` + r(91, 44, 18, 118, 9, k.m) + r(87, 26, 26, 30, 8, k.l) + r(90, 20, 20, 10, 2, k.a) + `</g>`,
  dumbbell: (k) =>
    r(60, 96, 80, 8, 4, G) + r(38, 70, 20, 60, 6, k.m) + r(142, 70, 20, 60, 6, k.m) + r(56, 80, 10, 40, 3, k.l) + r(134, 80, 10, 40, 3, k.l),
  football: (k) =>
    c(100, 100, 54, W, `stroke="${k.m}" stroke-width="5"`) + p("M100 76 L122 92 L114 118 H86 L78 92Z", k.m) + s("M100 76 V48 M122 92 L148 82 M114 118 L130 142 M86 118 L70 142 M78 92 L52 82", k.m, 4),
  basketball: (k) =>
    c(100, 100, 54, k.a) + s("M100 46 V154 M46 100 H154 M64 58 C86 84 86 116 64 142 M136 58 C114 84 114 116 136 142", k.m, 4, 'opacity=".85"'),
  bike: (k) =>
    c(54, 126, 30, "none", `stroke="${k.m}" stroke-width="6"`) + c(146, 126, 30, "none", `stroke="${k.m}" stroke-width="6"`) +
    s("M54 126 L82 84 H128 L146 126 M82 84 L100 126 H54 M128 84 L122 68 H138 M82 84 L76 72 H92", k.a, 5) + c(100, 126, 6, k.m),
  tent: (k) =>
    p("M26 152 L100 50 L174 152Z", k.m) + p("M100 88 L126 152 H74Z", k.l) + s("M100 50 V32", k.m, 3) + p("M100 32 L118 38 L100 44Z", k.a) + s("M20 152 H180", G, 4),
  console: (k) =>
    r(32, 86, 136, 46, 10, k.m) + r(46, 100, 74, 6, 3, k.l) + c(144, 109, 7, k.a) + r(46, 114, 40, 4, 2, G),
  videogame: (k) =>
    r(52, 36, 96, 128, 8, k.m) + r(60, 46, 80, 68, 4, k.l) + p("M80 100 L100 62 L120 100Z", k.a, 'opacity=".85"') + r(60, 122, 80, 12, 3, k.a) + r(60, 142, 44, 6, 3, G),
  controller: (k) =>
    p("M52 78 H148 C168 78 178 110 172 140 C168 156 150 158 140 142 L128 124 H72 L60 142 C50 158 32 156 28 140 C22 110 32 78 52 78Z", k.m) +
    r(52, 94, 22, 7, 3, k.l) + r(59, 87, 8, 21, 3, k.l) + c(136, 92, 5, k.a) + c(148, 102, 5, k.l) + c(124, 102, 5, k.l) + c(136, 112, 5, k.l) + c(86, 114, 8, k.l),
  gamingheadset: (k) =>
    M.headphones(k) + s("M44 148 Q50 172 86 170", k.m, 4) + c(90, 170, 7, k.a),
  gamingmonitor: (k) =>
    r(24, 50, 152, 82, 10, k.m) + r(30, 56, 140, 70, 5, D) + r(40, 96, 14, 22, 2, k.a) + r(60, 82, 14, 36, 2, k.l) + r(80, 70, 14, 48, 2, k.a) + r(100, 88, 14, 30, 2, k.l) + r(120, 76, 14, 42, 2, k.a) + r(140, 100, 14, 18, 2, k.l) +
    s("M100 132 V152", k.m, 8) + s("M70 158 H130", k.m, 8),
  chair: (k) =>
    r(62, 28, 76, 90, 22, k.m) + r(94, 36, 12, 74, 6, k.a) + r(54, 114, 92, 22, 10, k.m) + r(46, 96, 10, 32, 5, G) + r(144, 96, 10, 32, 5, G) + r(96, 136, 8, 18, 2, G) + s("M58 164 H142", G, 7) + c(62, 168, 5, k.m) + c(138, 168, 5, k.m) + c(100, 168, 5, k.m),
  teddy: (k) =>
    c(76, 46, 12, k.a) + c(124, 46, 12, k.a) + e(100, 134, 34, 36, k.a) + e(100, 138, 20, 24, k.l) + e(66, 128, 11, 20, k.a, 'transform="rotate(20 66 128)"') + e(134, 128, 11, 20, k.a, 'transform="rotate(-20 134 128)"') +
    c(100, 74, 30, k.a) + e(100, 84, 13, 10, k.l) + c(88, 68, 3.5, D) + c(112, 68, 3.5, D) + e(100, 80, 4, 3, D) + e(80, 160, 14, 10, k.a) + e(120, 160, 14, 10, k.a),
  doll: (k) =>
    p("M100 74 L138 154 H62Z", k.m) + c(100, 52, 22, k.l) + p("M78 52 C78 28 122 28 122 52 C122 44 112 38 100 38 C88 38 78 44 78 52Z", k.a) + c(93, 54, 2.5, D) + c(107, 54, 2.5, D) + r(88, 154, 8, 16, 3, k.l) + r(104, 154, 8, 16, 3, k.l) + s("M82 106 H118", k.a, 5),
  figure: (k) =>
    c(100, 44, 15, k.l) + r(76, 62, 48, 54, 9, k.m) + r(56, 64, 17, 50, 8, k.m) + r(127, 64, 17, 50, 8, k.m) + r(78, 116, 20, 50, 6, k.a) + r(102, 116, 20, 50, 6, k.a) + c(100, 88, 9, k.a),
  blocks: (k) =>
    r(52, 112, 96, 42, 4, k.m) + keys(62, 106, 4, 1, 14, 6, 8, k.m) + r(64, 72, 72, 42, 4, k.a) + keys(72, 66, 3, 1, 14, 6, 8, k.a) + r(78, 36, 44, 38, 4, k.l, `stroke="${k.m}" stroke-width="2"`) + keys(84, 30, 2, 1, 14, 6, 8, k.l),
  abc: (k) =>
    r(40, 96, 56, 56, 6, k.a) + r(104, 96, 56, 56, 6, k.m) + r(72, 42, 56, 56, 6, k.l, `stroke="${k.m}" stroke-width="3"`) +
    `<g font-family="Arial, sans-serif" font-weight="700" font-size="36" text-anchor="middle"><text x="68" y="136" fill="${W}">A</text><text x="132" y="136" fill="${W}">B</text><text x="100" y="82" fill="${k.m}">C</text></g>`,
  babybottle: (k) =>
    p("M88 64 Q100 22 112 64Z", k.a) + r(72, 62, 56, 14, 4, k.m) + r(76, 74, 48, 88, 14, k.l, `stroke="${k.m}" stroke-width="4"`) + s("M84 96 H100 M84 112 H100 M84 128 H100", k.m, 3),
  backpack: (k) =>
    s("M90 52 V40 a10 10 0 0 1 20 0 V52", k.m, 6) + r(54, 50, 92, 112, 28, k.m) + r(68, 108, 64, 42, 10, k.l) + s("M68 128 H132", k.m, 2) + r(68, 76, 64, 6, 3, k.a),
  waterbottle: (k) =>
    r(82, 32, 36, 26, 6, k.a) + r(72, 56, 56, 108, 16, k.m) + r(72, 96, 56, 10, 0, k.l),
  vacuum: (k) =>
    c(100, 100, 60, k.m) + c(100, 100, 48, "none", `stroke="${k.l}" stroke-width="3"`) + c(100, 100, 17, k.l) + c(100, 100, 6, k.a) + c(100, 58, 8, D) + c(60, 130, 6, k.a) + c(140, 130, 6, k.a),
  espresso: (k) =>
    r(48, 38, 104, 114, 10, k.m) + r(48, 38, 104, 24, 10, k.l) + r(94, 84, 12, 14, 3, G) + s("M100 100 V112", k.a, 3) + r(82, 116, 36, 28, 5, W) + r(48, 152, 104, 10, 3, D) + c(66, 50, 4, k.a),
  dining: (k) =>
    c(100, 100, 52, W, `stroke="${G}" stroke-width="4"`) + c(100, 100, 34, "none", `stroke="${k.l}" stroke-width="3"`) +
    s("M30 60 V100 M24 60 V86 M36 60 V86 M30 100 V150", k.m, 4) + p("M170 60 C158 72 158 100 170 104 V150", "none", `stroke="${k.m}" stroke-width="4"`)
};

const ALIASES = { runningshoe: "shoe", gamingkeyboard: "keyboard" };

function render(name, paletteIndex, opts) {
  const k = PALETTES[(paletteIndex || 0) % PALETTES.length];
  const motif = M[ALIASES[name] || name];
  if (!motif) throw new Error("Unknown motif: " + name);
  const o = opts || {};
  const vb = o.hero ? "0 0 320 200" : "0 0 320 200";
  return (
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${vb}" role="img">` +
    `<defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${k.bg}"/><stop offset="1" stop-color="#e6e9ec"/></linearGradient></defs>` +
    `<rect width="320" height="200" fill="url(#g)"/>` +
    `<circle cx="160" cy="98" r="82" fill="#ffffff" opacity=".7"/>` +
    `<ellipse cx="160" cy="178" rx="62" ry="6" fill="#101c2b" opacity=".12"/>` +
    `<g transform="translate(60 0)">${motif(k)}</g></svg>\n`
  );
}

module.exports = { render, MOTIFS: Object.keys(M), PALETTES, motifs: M };

if (require.main === module) {
  const fs = require("fs");
  const out = process.argv[2];
  if (!out) {
    console.log("usage: node motifs.js <outDir>");
    process.exit(1);
  }
  fs.mkdirSync(out, { recursive: true });
  Object.keys(M).forEach(function (name) {
    fs.writeFileSync(out + "/" + name + ".svg", render(name, 0));
  });
  console.log(Object.keys(M).length + " motifs written to " + out);
}
