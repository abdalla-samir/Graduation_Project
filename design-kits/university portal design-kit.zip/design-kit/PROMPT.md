# Prompt: build any lab with the Lab Design System

How to use: start a new chat, attach `DESIGN_SYSTEM.md`, the lab description (Notion text or file), and the back-end project (zip). Best: attach `design-kit.zip` (it contains the design system, this prompt, `motifs.js` and the ready `assets/` photos and SVGs). Optional: your own images zip. Copy the text between the lines, fill the brackets you care about (all are optional), and send.

------------------------------------------------------------

I want to create a CTF / vulnerable-application lab. I attached:
1. The lab description (the vulnerability, the exploit path, the flag, the fix). It is the source of truth: build the lab exactly as it describes, nothing more.
2. The back-end project (any stack) as a zip. [If I did not attach one, say so in your plan: build the front-end plus a small mock API and tell me which endpoints the back-end needs.]
3. DESIGN_SYSTEM.md. Read all of it before you start and follow it exactly. Do not ask me for the original design files; the document is the design.
4. [Optional] A reference image of the layout I want. If I attach one, follow it closely for every page (layout, sidebar, header, cards, spacing) using the kit tokens and section 5.4.
5. [Optional] design-kit.zip (assets/ has ready photos and SVG motifs; use them first) and/or my own images zip.

Task: build the front-end, link it to the back-end, make the lab solvable, and give it back as one project zip.

**Step 0. Plan (short, then continue without waiting)**
Tell me in a few lines: the back-end stack and how you will serve the static folder; the vulnerability class; the app theme you picked from the design system (name, brand, why); the list of pages you will build and the solve path they support. Then start building. Only stop to ask me if something blocks the work or has two very different readings.

**Step 1. Front-end**
- Put everything in the back-end's static folder so both share the same localhost.
- Plain HTML + plain JS + Tailwind v4, the shell, patterns, components and `common.js` from the design system, `./` relative paths, no frameworks/CDN/fonts/icon packs, no comments in code, calm layout.
- Make the app look like a real, reliable product that fits the lab's story. Rename the brand, pick the theme, and write believable content (names, records, mails) for that app. Keep the same layout and components.
- Build only the pages the lab needs (list, detail, forms, auth, demo mailbox, profile, etc.), all in the same style. The header must follow the login state and include Submit Flag.
- Follow section 10 of the design system: the front-end is honest and secure on its own, shows the normal surfaces a real app has, and never hints at the bug.
- If I ask for a View Source button, build it exactly as section 11.1 says and make sure the shown code has no flag, no secrets and no comments that reveal the bug.
- Add extra features around the vulnerable flow that a real app would have (for example resend code, security settings page), backed by small back-end endpoints that do not change the vulnerable logic; list them.
- Link every page to the real endpoints and field names of the back-end. Show API errors with the design system's message colors.

**Step 2. Back-end**
- Follow section 13: compare it with the lab description line by line; if it is missing the vulnerability or is the fixed version, change only what is needed to match the description and list every change.
- Make sure the static folder is served, the app can start, and the three shell endpoints exist (`/auth/me`, `/auth/logout`, `/lab/check-flag`). Add or adapt them if missing and tell me.
- Keep seed data exactly as described. Do not add protections the description does not mention. Tell me about any unintended shortcut you notice instead of silently fixing it.

**Step 3. Verify**
- If you can run the back-end, test against it. If not (for example no SDK), test against a small mock server that mirrors the endpoints and say clearly that the real back-end was not compiled or started.
- In a real browser, desktop and 390px wide: walk the full solve path to the flag, check the header state changes, images load, there are no console errors, and the flag is accepted.
- Rebuild the CSS and make sure every class is in `output.css`.

**Step 4. Deliver**
- One zip: back-end + static folder + `package.json` + built `output.css`.
- Then tell me, briefly: the solve steps (numbered), where the bug is in the code, how it matches or differs from the original report/description, the fix, what you changed in the back-end, and a short list of things I should check myself.

Lab details (optional):
- Lab name: [name]
- App theme or look I want: [for example: bank, hospital, social network, food delivery, or "choose for me"]
- Brand name: [name or "choose for me"]
- Flag / ports / extra accounts: [anything special]
- View Source button for players: [yes / no] (yes = section 11.1: whitebox viewer with sanitized copies of the back-end files)
- Pictures: [use the kit assets / my images zip / drawn motifs / no pictures needed]

------------------------------------------------------------

## Short version (when the attachments already explain everything)

Build this lab from the attached lab description and back-end using the attached DESIGN_SYSTEM.md. Follow the document exactly (plain HTML/JS/Tailwind v4 in the back-end's static folder, `./` paths, no comments, calm layout, honest front-end that never hints at the bug). Pick the matching theme, build only the needed pages, audit the back-end against the description (change only what is needed and list changes), test the full solve path in a browser, and give me one zip plus the solve steps, bug location, fix, and what to check.

## Tips

- Same design on every lab: always attach the same `DESIGN_SYSTEM.md`. Only the theme row, brand and content change.
- Different look: tell the assistant to use a different preset (`bank`, `social`, `desk`, `health`, `food`, `admin`) or to derive colors from a brand.
- A lab with no login: say so; the shell drops the account block and keeps Submit Flag.
- If something looks off, ask for the specific page and viewport; the design system's checklist (section 14) is what gets re-checked.
