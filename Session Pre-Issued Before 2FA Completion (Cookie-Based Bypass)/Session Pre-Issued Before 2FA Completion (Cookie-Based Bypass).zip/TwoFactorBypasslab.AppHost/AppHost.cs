var builder = DistributedApplication.CreateBuilder(args);

builder.AddDotnetProject("apiservice", "../TwoFactorBypasslab.ApiService/TwoFactorBypasslab.ApiService.csproj")
    .WithExternalHttpEndpoints()
    .WithHttpHealthCheck("/health");

builder.Build().Run();
