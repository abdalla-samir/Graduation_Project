﻿namespace TwoFactorBypassLab.Data;

public class LabUser
{
    public int Id { get; set; }
    public string Username { get; set; } = "";
    public string Password { get; set; } = "";
    public bool TwoFactorEnabled { get; set; } = true;
}

public class LabData
{
    public List<LabUser> Users { get; } = new()
    {
        new LabUser
        {
            Id = 1,
            Username = "player",
            Password = "Player123!"
        },
        new LabUser
        {
            Id = 2,
            Username = "omar",
            Password = "Omar123!"
        }
    };
}