﻿namespace TwoFactorBypassLab.Data;

public class LoginSession
{
    public string SessionId { get; set; } = "";
    public int UserId { get; set; }

    public bool MfaVerified { get; set; } = false;
    public string OtpCode { get; set; } = "";
    public DateTime OtpExpiresAt { get; set; }
}

public class SessionData
{
    public List<LoginSession> Sessions { get; } = new();
}