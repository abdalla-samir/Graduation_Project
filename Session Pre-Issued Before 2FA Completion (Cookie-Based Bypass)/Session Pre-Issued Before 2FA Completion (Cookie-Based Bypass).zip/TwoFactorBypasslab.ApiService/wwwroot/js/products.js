(function () {
  var PER_PAGE = 12;
  var page = 1;

  var STAR_FULL =
    '<svg class="w-4 h-4 text-cta" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/></svg>';
  var STAR_EMPTY =
    '<svg class="w-4 h-4 text-cta" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/></svg>';

  var PHOTO = {'laptops':'laptop','monitors':'monitor','gaming-monitors':'monitor','keyboards':'keyboard','gaming-keyboards-mice':'keyboard','mice':'mouse','smartphones':'phones','gaming-headsets':'headset','gaming-chairs':'gaming-chair','furniture':'furniture','home-decor':'home-decor','kitchen-dining':'kitchen','storage-organization':'storage','skincare':'skin-care','makeup':'makeup','hair-care':'hair-care','fragrances':'fragrance','shoes':'shoes-2','running':'shoes-2','electronics-accessories':'electronics-accessories','action-figures':'gaming-figure','building-construction':'building-sets','video-games':'games','mens-clothing':'men-fashion','womens-clothing':'women-fashion','fashion-accessories':'fashion-accessories'};
  function imgFor(p) {
    return PHOTO[p.subcategory] ? './img/photo/' + PHOTO[p.subcategory] + '.jpg' : './img/p/' + p.id + '.svg';
  }
  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function query() {
    return new URLSearchParams(location.search);
  }

  function stars(n) {
    var out = "";
    for (var i = 1; i <= 5; i++) out += i <= Math.round(n) ? STAR_FULL : STAR_EMPTY;
    return out;
  }

  function findCategory(slug) {
    return ALL_CATEGORIES.filter(function (c) {
      return c.slug === slug;
    })[0];
  }

  function findSub(category, slug) {
    if (!category) return null;
    return (
      category.subcategories.filter(function (s) {
        return s.slug === slug;
      })[0] || null
    );
  }

  function readFilters() {
    var q = query();
    var brands = q.get("brands");
    var category = q.get("category");
    return {
      category: category && category !== "all" ? category : null,
      subcategory: q.get("subcategory"),
      brands: brands ? brands.split(",") : null,
      rating: q.get("rating"),
      outOfStock: q.get("out-of-stock") !== null,
      min: q.get("min"),
      max: q.get("max"),
      sort: q.get("sort-by") || "relevance",
      search: q.get("search")
    };
  }

  function matches(p, f) {
    return (
      (!f.category || p.category === f.category) &&
      (!f.subcategory || p.subcategory === f.subcategory) &&
      (!f.brands || f.brands.indexOf(p.brand) !== -1) &&
      (!f.rating || p.rating > Number(f.rating)) &&
      (f.outOfStock ? true : p.inStock === true) &&
      (!f.min || p.price >= Number(f.min)) &&
      (!f.max || p.price <= Number(f.max)) &&
      (!f.search || p.name.toLowerCase().indexOf(f.search.toLowerCase()) !== -1)
    );
  }

  function sortList(list, sort) {
    var copy = list.slice();
    if (sort === "price-asc") copy.sort(function (a, b) { return a.price - b.price; });
    if (sort === "price-desc") copy.sort(function (a, b) { return b.price - a.price; });
    if (sort === "rating") copy.sort(function (a, b) { return b.rating - a.rating; });
    return copy;
  }

  function go(mutate) {
    var q = query();
    mutate(q);
    var qs = q.toString();
    history.replaceState(null, "", "./products.html" + (qs ? "?" + qs : ""));
    page = 1;
    render();
  }

  function toast(message) {
    var t = document.getElementById("toast");
    t.textContent = message;
    t.classList.remove("translate-x-full");
    setTimeout(function () {
      t.classList.add("translate-x-full");
    }, 3000);
  }

  function renderBreadcrumbs(f) {
    var category = f.category ? findCategory(f.category) : null;
    var sub = category ? findSub(category, f.subcategory) : null;
    var html = '<li><a href="./index.html" class="text-secondary">Home</a></li>';
    var chev = '<li class="text-text-secondary text-xs">&gt;</li>';

    if (!category) {
      html += chev + "<li><span>All Products</span></li>";
    } else if (sub) {
      html +=
        chev +
        '<li><a href="./products.html?category=' + esc(category.slug) + '" class="text-secondary">' + esc(category.name) + "</a></li>" +
        chev + "<li><span>" + esc(sub.name) + "</span></li>";
    } else {
      html += chev + "<li><span>" + esc(category.name) + "</span></li>";
    }

    document.getElementById("breadcrumbs").innerHTML = html;
  }

  function renderHeader(f, total, start, end) {
    var category = f.category ? findCategory(f.category) : null;
    var sub = category ? findSub(category, f.subcategory) : null;

    document.getElementById("results-title").textContent = category ? category.name : "All Products";

    var subEl = document.getElementById("results-sub");
    subEl.textContent = sub ? sub.name : "";
    subEl.classList.toggle("hidden", !sub);

    document.getElementById("results-count").innerHTML =
      total + (total === 1 ? " result" : " results");

    document.getElementById("sort").value = f.sort;
  }

  function filterBlock(title, inner) {
    return '<div class="p-4"><h3>' + title + "</h3>" + inner + "</div>";
  }

  function renderFilters(f) {
    var category = f.category ? findCategory(f.category) : null;
    var html = '<h3 class="p-4">Filter Results</h3>';

    if (category) {
      var items =
        '<li data-nav="' + esc(category.slug) + '" class="' + (!f.subcategory ? "text-danger " : "") +
        'hover:text-danger cursor-pointer w-fit">All</li>';
      category.subcategories.forEach(function (s) {
        items +=
          '<li data-nav="' + esc(category.slug) + '" data-sub="' + esc(s.slug) + '" class="' +
          (f.subcategory === s.slug ? "text-danger " : "") +
          'hover:text-danger cursor-pointer w-fit">' + esc(s.name) + "</li>";
      });
      html += filterBlock("Departments", '<ul class="p-2 space-y-1">' + items + "</ul>");
    }

    var rating = Number(f.rating || 0);
    var starsHtml = "";
    for (var i = 1; i <= 5; i++) {
      starsHtml += '<li class="cursor-pointer" data-star="' + i + '">' + (rating >= i ? STAR_FULL : STAR_EMPTY) + "</li>";
    }
    html += filterBlock(
      "Customer Reviews",
      '<div class="flex justify-between items-center"><div class="flex items-center gap-2 h-5"><ul class="flex">' +
        starsHtml + "</ul>" + (rating < 5 ? '<span class="text-sm text-primary">&amp; Up</span>' : "") +
        '</div><button type="button" data-star="0" class="text-secondary text-sm hover:underline cursor-pointer">Clear</button></div>'
    );

    if (!category) {
      var cats = ALL_CATEGORIES.map(function (c) {
        return '<li data-nav="' + esc(c.slug) + '" class="hover:text-danger cursor-pointer w-fit">' + esc(c.name) + "</li>";
      }).join("");
      html += filterBlock("Categories", '<ul class="p-2 space-y-1">' + cats + "</ul>");
    } else {
      var seen = {};
      var brands = PRODUCTS.filter(function (p) {
        return f.subcategory ? p.subcategory === f.subcategory : p.category === f.category;
      })
        .map(function (p) {
          return p.brand;
        })
        .filter(function (b) {
          if (seen[b]) return false;
          seen[b] = true;
          return true;
        });
      var boxes = brands
        .map(function (b) {
          var on = f.brands && f.brands.indexOf(b) !== -1;
          return (
            '<label class="cursor-pointer w-fit"><input type="checkbox" data-brand="' + esc(b) + '"' +
            (on ? " checked" : "") + "><span>" + esc(b) + "</span></label>"
          );
        })
        .join("");
      html += filterBlock("Brand", "<fieldset>" + boxes + "</fieldset>");
    }

    html += filterBlock(
      "Price",
      '<fieldset class="space-y-1">' +
        '<input id="min" type="number" min="0" step="0.01" placeholder="$ Min" value="' + esc(f.min || "") + '">' +
        '<input id="max" type="number" min="0" step="0.01" placeholder="$ Max" value="' + esc(f.max || "") + '">' +
        '<button type="button" id="price-go" class="btn btn-secondary">Go</button>' +
        (f.min || f.max ? '<button type="button" id="price-clear" class="btn border-black">Clear</button>' : "") +
        "</fieldset>"
    );

    html += filterBlock(
      "Availability",
      '<label class="cursor-pointer"><input type="checkbox" id="stock"' + (f.outOfStock ? " checked" : "") +
        "><span>Include Out of Stock</span></label>"
    );

    document.getElementById("filters").innerHTML = html;
  }

  function productCard(p) {
    var info = "";
    (p.info || []).forEach(function (i) {
      if (info) return;
      if (i.type === "badge")
        info = '<div class="bg-background text-green-700 font-bold w-fit p-1 text-xs">' + esc(i.value) + "</div>";
      else if (i.type === "discount")
        info = '<div class="text-sm">Save <span class="text-danger font-medium">' + esc(i.value) + "</span> " + esc(i.text) + "</div>";
    });

    return (
      '<div class="bg-white p-2 shadow flex flex-col justify-between text-primary space-y-2">' +
      '<div class="space-y-2"><img src="' + imgFor(p) + '" alt="' + esc(p.name) + '" loading="lazy" class="w-full rounded-sm aspect-8/5 object-cover"><div class="space-y-1">' +
      '<a href="#" class="hover:text-danger w-fit font-medium line-clamp-2">' + esc(p.name) + "</a>" +
      '<div class="flex items-center gap-1"><div class="flex">' + stars(p.rating) + '</div><span class="text-xs text-secondary">' + p.rating.toFixed(1) + "</span></div>" +
      '<div class="flex items-end gap-1"><span class="font-bold text-primary text-xl">$' + p.price + "</span></div>" +
      "</div></div>" +
      '<div class="space-y-2">' + info +
      '<button type="button" class="' +
      (p.inStock ? "btn btn-secondary" : "btn bg-gray-300 text-gray-500 cursor-no-drop") + '">' +
      (p.inStock ? "Add to Cart" : "Out of Stock") + "</button></div></div>"
    );
  }

  function pageWindow(current, total) {
    var from = Math.max(1, current - 2);
    var to = Math.min(total, from + 4);
    from = Math.max(1, to - 4);
    var list = [];
    for (var i = from; i <= to; i++) list.push(i);
    return list;
  }

  function renderPagination(total) {
    var btn =
      "border h-10 w-20 border-border text-sm cursor-pointer hover:bg-secondary hover:text-white transition disabled:cursor-no-drop disabled:bg-gray-200 disabled:text-gray-500";
    var nums = pageWindow(page, total)
      .map(function (n) {
        return (
          '<button type="button" data-page="' + n + '" class="w-10 h-10 border border-border hover:bg-secondary hover:text-white cursor-pointer transition' +
          (n === page ? " bg-secondary text-white" : "") + '">' + n + "</button>"
        );
      })
      .join("");

    document.getElementById("pagination").innerHTML =
      '<button type="button" data-page="' + (page - 1) + '" class="' + btn + '"' + (page <= 1 ? " disabled" : "") + ">Previous</button>" +
      '<div class="hidden md:block space-x-2">' + nums + "</div>" +
      '<div class="md:hidden block"><span>' + page + "/" + total + "</span></div>" +
      '<button type="button" data-page="' + (page + 1) + '" class="' + btn + '"' + (page >= total ? " disabled" : "") + ">Next</button>";
  }

  function render() {
    var f = readFilters();
    var list = sortList(PRODUCTS.filter(function (p) { return matches(p, f); }), f.sort);
    var total = list.length;
    var pages = Math.max(1, Math.ceil(total / PER_PAGE));
    if (page > pages) page = pages;

    var startIdx = (page - 1) * PER_PAGE;
    var shown = list.slice(startIdx, startIdx + PER_PAGE);

    renderBreadcrumbs(f);
    renderHeader(f, total, total === 0 ? 0 : startIdx + 1, Math.min(page * PER_PAGE, total));
    renderFilters(f);

    document.getElementById("grid").innerHTML = shown.length
      ? shown.map(productCard).join("")
      : '<div class="bg-white p-6 col-span-full text-center"><h3>No products found</h3><p>Try changing or clearing your filters.</p></div>';

    renderPagination(pages);
  }

  function closeFilters() {
    var aside = document.getElementById("filters");
    aside.classList.add("-translate-x-full");
    aside.classList.remove("translate-x-0");
    document.getElementById("filters-overlay").classList.add("hidden");
  }

  function openFilters() {
    var aside = document.getElementById("filters");
    aside.classList.remove("-translate-x-full");
    aside.classList.add("translate-x-0");
    document.getElementById("filters-overlay").classList.remove("hidden");
  }

  document.getElementById("filters").addEventListener("click", function (e) {
    var nav = e.target.closest("[data-nav]");
    if (nav) {
      go(function (q) {
        ["subcategory", "brands", "rating", "min", "max", "out-of-stock", "search", "sort-by"].forEach(function (k) {
          q.delete(k);
        });
        q.set("category", nav.dataset.nav);
        if (nav.dataset.sub) q.set("subcategory", nav.dataset.sub);
      });
      closeFilters();
      return;
    }

    var star = e.target.closest("[data-star]");
    if (star) {
      go(function (q) {
        var n = Number(star.dataset.star);
        if (n === 0) q.delete("rating");
        else q.set("rating", n);
      });
      return;
    }

    if (e.target.id === "price-go") {
      var min = document.getElementById("min").value;
      var max = document.getElementById("max").value;
      if (min === "" && max === "") return toast("You should provide a minimum price and maximum price");
      if (Number(min) < 0) return toast("Minimum price must be positive number");
      if (Number(max) < 0) return toast("Maximum price must be positive number");
      if (max !== "" && Number(max) < Number(min))
        return toast("Maximum price must be greater than or equal to the minimum price.");
      go(function (q) {
        if (min !== "") q.set("min", min);
        if (max !== "") q.set("max", max);
      });
      return;
    }

    if (e.target.id === "price-clear") {
      go(function (q) {
        q.delete("min");
        q.delete("max");
      });
    }
  });

  document.getElementById("filters").addEventListener("change", function (e) {
    if (e.target.id === "stock") {
      go(function (q) {
        if (e.target.checked) q.set("out-of-stock", "true");
        else q.delete("out-of-stock");
      });
      return;
    }

    if (e.target.dataset.brand) {
      var checked = Array.prototype.slice
        .call(document.querySelectorAll("[data-brand]"))
        .filter(function (b) { return b.checked; })
        .map(function (b) { return b.dataset.brand; });
      go(function (q) {
        if (checked.length) q.set("brands", checked.join(","));
        else q.delete("brands");
      });
    }
  });

  document.getElementById("sort").addEventListener("change", function (e) {
    go(function (q) {
      q.set("sort-by", e.target.value);
    });
  });

  document.getElementById("pagination").addEventListener("click", function (e) {
    var b = e.target.closest("[data-page]");
    if (!b || b.disabled) return;
    page = Number(b.dataset.page);
    render();
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  document.getElementById("filters-open").addEventListener("click", openFilters);
  document.getElementById("filters-overlay").addEventListener("click", closeFilters);

  render();
})();
