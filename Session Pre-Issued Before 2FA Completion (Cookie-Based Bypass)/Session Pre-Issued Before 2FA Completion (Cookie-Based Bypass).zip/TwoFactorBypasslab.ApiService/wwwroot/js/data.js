var ALL_CATEGORIES = [
  {
    "name": "Electronics",
    "slug": "electronics",
    "subcategories": [
      {
        "name": "Headphones & Earbuds",
        "slug": "headphones-earbuds"
      },
      {
        "name": "Cameras & Photography",
        "slug": "cameras-photography"
      },
      {
        "name": "Televisions",
        "slug": "televisions"
      },
      {
        "name": "Audio & Home Theater",
        "slug": "audio-home-theater"
      },
      {
        "name": "Wearable Technology",
        "slug": "wearable-technology"
      },
      {
        "name": "Smart Home",
        "slug": "smart-home"
      },
      {
        "name": "Accessories",
        "slug": "electronics-accessories"
      }
    ]
  },
  {
    "name": "Computers & Accessories",
    "slug": "computers-accessories",
    "subcategories": [
      {
        "name": "Laptops",
        "slug": "laptops"
      },
      {
        "name": "Desktop Computers",
        "slug": "desktop-computers"
      },
      {
        "name": "Monitors",
        "slug": "monitors"
      },
      {
        "name": "Keyboards",
        "slug": "keyboards"
      },
      {
        "name": "Mice",
        "slug": "mice"
      },
      {
        "name": "Computer Components",
        "slug": "computer-components"
      },
      {
        "name": "Storage",
        "slug": "storage"
      },
      {
        "name": "Printers & Scanners",
        "slug": "printers-scanners"
      },
      {
        "name": "Computer Accessories",
        "slug": "computer-accessories"
      }
    ]
  },
  {
    "name": "Mobiles & Tablets",
    "slug": "mobiles-tablets",
    "subcategories": [
      {
        "name": "Smartphones",
        "slug": "smartphones"
      },
      {
        "name": "Tablets",
        "slug": "tablets"
      },
      {
        "name": "Mobile Cases",
        "slug": "mobile-cases"
      },
      {
        "name": "Chargers & Cables",
        "slug": "chargers-cables"
      },
      {
        "name": "Power Banks",
        "slug": "power-banks"
      },
      {
        "name": "Screen Protectors",
        "slug": "screen-protectors"
      },
      {
        "name": "Mobile Accessories",
        "slug": "mobile-accessories"
      }
    ]
  },
  {
    "name": "Fashion",
    "slug": "fashion",
    "subcategories": [
      {
        "name": "Men's Clothing",
        "slug": "mens-clothing"
      },
      {
        "name": "Women's Clothing",
        "slug": "womens-clothing"
      },
      {
        "name": "Kids' Clothing",
        "slug": "kids-clothing"
      },
      {
        "name": "Shoes",
        "slug": "shoes"
      },
      {
        "name": "Bags",
        "slug": "bags"
      },
      {
        "name": "Watches",
        "slug": "watches"
      },
      {
        "name": "Jewelry",
        "slug": "jewelry"
      },
      {
        "name": "Accessories",
        "slug": "fashion-accessories"
      }
    ]
  },
  {
    "name": "Home & Living",
    "slug": "home-living",
    "subcategories": [
      {
        "name": "Furniture",
        "slug": "furniture"
      },
      {
        "name": "Home Decor",
        "slug": "home-decor"
      },
      {
        "name": "Kitchen & Dining",
        "slug": "kitchen-dining"
      },
      {
        "name": "Bedding",
        "slug": "bedding"
      },
      {
        "name": "Bath",
        "slug": "bath"
      },
      {
        "name": "Lighting",
        "slug": "lighting"
      },
      {
        "name": "Storage & Organization",
        "slug": "storage-organization"
      },
      {
        "name": "Home Appliances",
        "slug": "home-appliances"
      }
    ]
  },
  {
    "name": "Beauty & Personal Care",
    "slug": "beauty",
    "subcategories": [
      {
        "name": "Skincare",
        "slug": "skincare"
      },
      {
        "name": "Makeup",
        "slug": "makeup"
      },
      {
        "name": "Hair Care",
        "slug": "hair-care"
      },
      {
        "name": "Fragrances",
        "slug": "fragrances"
      },
      {
        "name": "Personal Care",
        "slug": "personal-care"
      },
      {
        "name": "Men's Grooming",
        "slug": "mens-grooming"
      },
      {
        "name": "Beauty Tools",
        "slug": "beauty-tools"
      }
    ]
  },
  {
    "name": "Sports & Outdoors",
    "slug": "sports",
    "subcategories": [
      {
        "name": "Exercise & Fitness",
        "slug": "exercise-fitness"
      },
      {
        "name": "Running",
        "slug": "running"
      },
      {
        "name": "Football",
        "slug": "football"
      },
      {
        "name": "Basketball",
        "slug": "basketball"
      },
      {
        "name": "Cycling",
        "slug": "cycling"
      },
      {
        "name": "Camping & Hiking",
        "slug": "camping-hiking"
      },
      {
        "name": "Outdoor Recreation",
        "slug": "outdoor-recreation"
      },
      {
        "name": "Sports Accessories",
        "slug": "sports-accessories"
      }
    ]
  },
  {
    "name": "Gaming",
    "slug": "gaming",
    "subcategories": [
      {
        "name": "Gaming Consoles",
        "slug": "gaming-consoles"
      },
      {
        "name": "Video Games",
        "slug": "video-games"
      },
      {
        "name": "Gaming Controllers",
        "slug": "gaming-controllers"
      },
      {
        "name": "Gaming Headsets",
        "slug": "gaming-headsets"
      },
      {
        "name": "Gaming Keyboards & Mice",
        "slug": "gaming-keyboards-mice"
      },
      {
        "name": "Gaming Monitors",
        "slug": "gaming-monitors"
      },
      {
        "name": "Gaming Chairs",
        "slug": "gaming-chairs"
      },
      {
        "name": "Gaming Accessories",
        "slug": "gaming-accessories"
      }
    ]
  },
  {
    "name": "Toys & Kids",
    "slug": "toys-kids",
    "subcategories": [
      {
        "name": "Toys",
        "slug": "toys"
      },
      {
        "name": "Action Figures",
        "slug": "action-figures"
      },
      {
        "name": "Dolls & Accessories",
        "slug": "dolls-accessories"
      },
      {
        "name": "Building & Construction",
        "slug": "building-construction"
      },
      {
        "name": "Educational Toys",
        "slug": "educational-toys"
      },
      {
        "name": "Outdoor Toys",
        "slug": "outdoor-toys"
      },
      {
        "name": "Baby Products",
        "slug": "baby-products"
      },
      {
        "name": "Kids' Accessories",
        "slug": "kids-accessories"
      }
    ]
  }
];

var PRODUCTS = [{"id":1,"name":"Sony WH-1000XM5 Wireless Headphones","brand":"Sony","price":349.99,"rating":4.7,"inStock":false,"category":"electronics","subcategory":"headphones-earbuds","info":[{"type":"discount","value":"10%","text":"today"},{"type":"shipping","value":"Egypt"}]},{"id":2,"name":"Apple AirPods Pro 2","brand":"Apple","price":249.99,"rating":4.8,"inStock":true,"category":"electronics","subcategory":"headphones-earbuds","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":3,"name":"Samsung Galaxy Buds3 Pro","brand":"Samsung","price":199.99,"rating":4.5,"inStock":true,"category":"electronics","subcategory":"headphones-earbuds","info":[{"type":"discount","value":"$20","text":"with this deal"},{"type":"shipping","value":"Egypt"}]},{"id":4,"name":"Bose QuietComfort Ultra","brand":"Bose","price":429.99,"rating":4.6,"inStock":false,"category":"electronics","subcategory":"headphones-earbuds","info":[{"type":"badge","value":"Limited Offer"}]},{"id":5,"name":"Canon EOS R6 Mark II","brand":"Canon","price":2499.99,"rating":4.8,"inStock":true,"category":"electronics","subcategory":"cameras-photography","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":6,"name":"Sony Alpha A7 IV","brand":"Sony","price":2498,"rating":4.8,"inStock":true,"category":"electronics","subcategory":"cameras-photography","info":[{"type":"discount","value":"10%","text":"today"},{"type":"shipping","value":"Egypt"}]},{"id":7,"name":"Nikon Z6 III","brand":"Nikon","price":2496.95,"rating":4.7,"inStock":true,"category":"electronics","subcategory":"cameras-photography","info":[{"type":"discount","value":"$20","text":"with this deal"}]},{"id":8,"name":"Samsung 55 Inch QLED 4K TV","brand":"Samsung","price":899.99,"rating":4.6,"inStock":true,"category":"electronics","subcategory":"televisions","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":9,"name":"LG 65 Inch OLED 4K TV","brand":"LG","price":1599.99,"rating":4.8,"inStock":true,"category":"electronics","subcategory":"televisions","info":[{"type":"discount","value":"10%","text":"today"},{"type":"badge","value":"Limited Offer"}]},{"id":10,"name":"Sony Bravia 55 Inch 4K TV","brand":"Sony","price":1099.99,"rating":4.7,"inStock":true,"category":"electronics","subcategory":"televisions","info":[{"type":"shipping","value":"Egypt"}]},{"id":11,"name":"Sonos Arc Soundbar","brand":"Sonos","price":899.99,"rating":4.7,"inStock":true,"category":"electronics","subcategory":"audio-home-theater","info":[{"type":"badge","value":"Best Seller"}]},{"id":12,"name":"Bose Smart Soundbar","brand":"Bose","price":499.99,"rating":4.5,"inStock":true,"category":"electronics","subcategory":"audio-home-theater","info":[{"type":"discount","value":"10%","text":"today"},{"type":"shipping","value":"Egypt"}]},{"id":13,"name":"Apple Watch Series 10","brand":"Apple","price":429.99,"rating":4.7,"inStock":true,"category":"electronics","subcategory":"wearable-technology","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":14,"name":"Samsung Galaxy Watch 7","brand":"Samsung","price":299.99,"rating":4.5,"inStock":true,"category":"electronics","subcategory":"wearable-technology","info":[{"type":"discount","value":"$20","text":"with this deal"}]},{"id":15,"name":"Amazon Echo Dot","brand":"Amazon","price":49.99,"rating":4.6,"inStock":true,"category":"electronics","subcategory":"smart-home","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":16,"name":"Google Nest Hub","brand":"Google","price":99.99,"rating":4.4,"inStock":true,"category":"electronics","subcategory":"smart-home","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":17,"name":"Anker USB-C Hub","brand":"Anker","price":39.99,"rating":4.5,"inStock":true,"category":"electronics","subcategory":"electronics-accessories","info":[{"type":"shipping","value":"Egypt"}]},{"id":18,"name":"Belkin Wireless Charger","brand":"Belkin","price":59.99,"rating":4.4,"inStock":true,"category":"electronics","subcategory":"electronics-accessories","info":[{"type":"discount","value":"$10","text":"with this deal"},{"type":"shipping","value":"Egypt"}]},{"id":19,"name":"MacBook Air M3","brand":"Apple","price":1099.99,"rating":4.8,"inStock":true,"category":"computers-accessories","subcategory":"laptops","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":20,"name":"Dell XPS 15","brand":"Dell","price":1499.99,"rating":4.6,"inStock":true,"category":"computers-accessories","subcategory":"laptops","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":21,"name":"Lenovo ThinkPad X1 Carbon","brand":"Lenovo","price":1399.99,"rating":4.7,"inStock":true,"category":"computers-accessories","subcategory":"laptops","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":22,"name":"ASUS ROG Zephyrus G16","brand":"ASUS","price":1799.99,"rating":4.7,"inStock":true,"category":"computers-accessories","subcategory":"laptops","info":[{"type":"discount","value":"$50","text":"with this deal"},{"type":"badge","value":"Limited Offer"}]},{"id":23,"name":"Apple Mac Mini M4","brand":"Apple","price":599.99,"rating":4.8,"inStock":true,"category":"computers-accessories","subcategory":"desktop-computers","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":24,"name":"Dell Inspiron Desktop","brand":"Dell","price":749.99,"rating":4.4,"inStock":true,"category":"computers-accessories","subcategory":"desktop-computers","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":25,"name":"LG UltraGear 27 Inch","brand":"LG","price":399.99,"rating":4.6,"inStock":true,"category":"computers-accessories","subcategory":"monitors","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":26,"name":"Samsung Odyssey G7","brand":"Samsung","price":649.99,"rating":4.7,"inStock":true,"category":"computers-accessories","subcategory":"monitors","info":[{"type":"discount","value":"$30","text":"with this deal"}]},{"id":27,"name":"Logitech MX Mechanical","brand":"Logitech","price":149.99,"rating":4.6,"inStock":true,"category":"computers-accessories","subcategory":"keyboards","info":[{"type":"shipping","value":"Egypt"}]},{"id":28,"name":"Keychron K2 Mechanical Keyboard","brand":"Keychron","price":99.99,"rating":4.5,"inStock":true,"category":"computers-accessories","subcategory":"keyboards","info":[{"type":"discount","value":"10%","text":"today"},{"type":"badge","value":"Limited Offer"}]},{"id":29,"name":"Logitech MX Master 3S","brand":"Logitech","price":99.99,"rating":4.7,"inStock":true,"category":"computers-accessories","subcategory":"mice","info":[{"type":"badge","value":"Best Seller"}]},{"id":30,"name":"Razer DeathAdder V3","brand":"Razer","price":69.99,"rating":4.6,"inStock":true,"category":"computers-accessories","subcategory":"mice","info":[{"type":"discount","value":"$10","text":"with this deal"},{"type":"shipping","value":"Egypt"}]},{"id":31,"name":"AMD Ryzen 7 7800X3D","brand":"AMD","price":399.99,"rating":4.9,"inStock":true,"category":"computers-accessories","subcategory":"computer-components","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":32,"name":"Intel Core i7 Processor","brand":"Intel","price":349.99,"rating":4.7,"inStock":true,"category":"computers-accessories","subcategory":"computer-components","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":33,"name":"Samsung 990 Pro 2TB SSD","brand":"Samsung","price":169.99,"rating":4.8,"inStock":true,"category":"computers-accessories","subcategory":"storage","info":[{"type":"badge","value":"Limited Offer"},{"type":"shipping","value":"Egypt"}]},{"id":34,"name":"WD Black 2TB NVMe SSD","brand":"Western Digital","price":149.99,"rating":4.7,"inStock":true,"category":"computers-accessories","subcategory":"storage","info":[{"type":"discount","value":"$15","text":"with this deal"}]},{"id":35,"name":"HP LaserJet Pro","brand":"HP","price":299.99,"rating":4.4,"inStock":true,"category":"computers-accessories","subcategory":"printers-scanners","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":36,"name":"Canon PIXMA Printer","brand":"Canon","price":149.99,"rating":4.5,"inStock":true,"category":"computers-accessories","subcategory":"printers-scanners","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":37,"name":"Logitech Webcam C920","brand":"Logitech","price":79.99,"rating":4.6,"inStock":true,"category":"computers-accessories","subcategory":"computer-accessories","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":38,"name":"iPhone 16 Pro","brand":"Apple","price":999.99,"rating":4.8,"inStock":true,"category":"mobiles-tablets","subcategory":"smartphones","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":39,"name":"Samsung Galaxy S25 Ultra","brand":"Samsung","price":1299.99,"rating":4.8,"inStock":true,"category":"mobiles-tablets","subcategory":"smartphones","info":[{"type":"discount","value":"10%","text":"today"},{"type":"shipping","value":"Egypt"}]},{"id":40,"name":"Google Pixel 9 Pro","brand":"Google","price":999.99,"rating":4.7,"inStock":true,"category":"mobiles-tablets","subcategory":"smartphones","info":[{"type":"badge","value":"Limited Offer"}]},{"id":41,"name":"OnePlus 13","brand":"OnePlus","price":899.99,"rating":4.6,"inStock":true,"category":"mobiles-tablets","subcategory":"smartphones","info":[{"type":"discount","value":"$30","text":"with this deal"},{"type":"shipping","value":"Egypt"}]},{"id":42,"name":"iPad Pro M4","brand":"Apple","price":1099.99,"rating":4.8,"inStock":true,"category":"mobiles-tablets","subcategory":"tablets","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":43,"name":"Samsung Galaxy Tab S10","brand":"Samsung","price":749.99,"rating":4.6,"inStock":true,"category":"mobiles-tablets","subcategory":"tablets","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":44,"name":"iPhone 16 Pro Silicone Case","brand":"Apple","price":49.99,"rating":4.4,"inStock":true,"category":"mobiles-tablets","subcategory":"mobile-cases","info":[{"type":"shipping","value":"Egypt"}]},{"id":45,"name":"Spigen Tough Armor Case","brand":"Spigen","price":29.99,"rating":4.7,"inStock":true,"category":"mobiles-tablets","subcategory":"mobile-cases","info":[{"type":"badge","value":"Best Seller"},{"type":"discount","value":"$5","text":"with this deal"}]},{"id":46,"name":"Anker 65W USB-C Charger","brand":"Anker","price":39.99,"rating":4.7,"inStock":true,"category":"mobiles-tablets","subcategory":"chargers-cables","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":47,"name":"Belkin USB-C Cable","brand":"Belkin","price":24.99,"rating":4.5,"inStock":true,"category":"mobiles-tablets","subcategory":"chargers-cables","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":48,"name":"Anker PowerCore 20K","brand":"Anker","price":49.99,"rating":4.7,"inStock":true,"category":"mobiles-tablets","subcategory":"power-banks","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":49,"name":"Baseus 20,000mAh Power Bank","brand":"Baseus","price":39.99,"rating":4.5,"inStock":true,"category":"mobiles-tablets","subcategory":"power-banks","info":[{"type":"discount","value":"$10","text":"with this deal"}]},{"id":50,"name":"Spigen Tempered Glass","brand":"Spigen","price":19.99,"rating":4.6,"inStock":true,"category":"mobiles-tablets","subcategory":"screen-protectors","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":51,"name":"PopSockets Phone Grip","brand":"PopSockets","price":14.99,"rating":4.4,"inStock":true,"category":"mobiles-tablets","subcategory":"mobile-accessories","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":52,"name":"Nike Men's Dri-FIT T-Shirt","brand":"Nike","price":29.99,"rating":4.6,"inStock":true,"category":"fashion","subcategory":"mens-clothing","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":53,"name":"Adidas Essentials Hoodie","brand":"Adidas","price":59.99,"rating":4.7,"inStock":true,"category":"fashion","subcategory":"mens-clothing","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":54,"name":"Puma Men's Jacket","brand":"Puma","price":89.99,"rating":4.5,"inStock":true,"category":"fashion","subcategory":"mens-clothing","info":[{"type":"shipping","value":"Egypt"}]},{"id":55,"name":"Zara Women's Blazer","brand":"Zara","price":99.99,"rating":4.5,"inStock":true,"category":"fashion","subcategory":"womens-clothing","info":[{"type":"badge","value":"Limited Offer"},{"type":"discount","value":"$15","text":"with this deal"}]},{"id":56,"name":"H&M Women's Sweater","brand":"H&M","price":39.99,"rating":4.4,"inStock":true,"category":"fashion","subcategory":"womens-clothing","info":[{"type":"discount","value":"10%","text":"today"},{"type":"shipping","value":"Egypt"}]},{"id":57,"name":"Nike Kids Sports Set","brand":"Nike","price":49.99,"rating":4.6,"inStock":true,"category":"fashion","subcategory":"kids-clothing","info":[{"type":"badge","value":"Best Seller"}]},{"id":58,"name":"Adidas Kids Hoodie","brand":"Adidas","price":44.99,"rating":4.5,"inStock":true,"category":"fashion","subcategory":"kids-clothing","info":[{"type":"shipping","value":"Egypt"}]},{"id":59,"name":"Nike Air Max 270","brand":"Nike","price":149.99,"rating":4.8,"inStock":true,"category":"fashion","subcategory":"shoes","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":60,"name":"Adidas Ultraboost","brand":"Adidas","price":179.99,"rating":4.7,"inStock":true,"category":"fashion","subcategory":"shoes","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":61,"name":"New Balance 990v6","brand":"New Balance","price":199.99,"rating":4.8,"inStock":true,"category":"fashion","subcategory":"shoes","info":[{"type":"badge","value":"Limited Offer"},{"type":"shipping","value":"Egypt"}]},{"id":62,"name":"Nike Sports Backpack","brand":"Nike","price":69.99,"rating":4.5,"inStock":true,"category":"fashion","subcategory":"bags","info":[{"type":"discount","value":"$10","text":"with this deal"}]},{"id":63,"name":"Samsonite Travel Backpack","brand":"Samsonite","price":119.99,"rating":4.6,"inStock":true,"category":"fashion","subcategory":"bags","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":64,"name":"Apple Watch Series 10","brand":"Apple","price":429.99,"rating":4.7,"inStock":true,"category":"fashion","subcategory":"watches","info":[{"type":"badge","value":"Best Seller"}]},{"id":65,"name":"Casio G-Shock","brand":"Casio","price":129.99,"rating":4.6,"inStock":true,"category":"fashion","subcategory":"watches","info":[{"type":"discount","value":"10%","text":"today"},{"type":"shipping","value":"Egypt"}]},{"id":66,"name":"Swarovski Crystal Necklace","brand":"Swarovski","price":149.99,"rating":4.5,"inStock":true,"category":"fashion","subcategory":"jewelry","info":[{"type":"badge","value":"Limited Offer"}]},{"id":67,"name":"Pandora Silver Bracelet","brand":"Pandora","price":99.99,"rating":4.6,"inStock":true,"category":"fashion","subcategory":"jewelry","info":[{"type":"discount","value":"$15","text":"with this deal"},{"type":"shipping","value":"Egypt"}]},{"id":68,"name":"Ray-Ban Aviator Sunglasses","brand":"Ray-Ban","price":179.99,"rating":4.7,"inStock":true,"category":"fashion","subcategory":"fashion-accessories","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":69,"name":"IKEA Modern Sofa","brand":"IKEA","price":599.99,"rating":4.5,"inStock":true,"category":"home-living","subcategory":"furniture","info":[{"type":"discount","value":"10%","text":"today"},{"type":"shipping","value":"Egypt"}]},{"id":70,"name":"Ashley Dining Table","brand":"Ashley","price":799.99,"rating":4.6,"inStock":true,"category":"home-living","subcategory":"furniture","info":[{"type":"badge","value":"Limited Offer"}]},{"id":71,"name":"IKEA Wall Mirror","brand":"IKEA","price":89.99,"rating":4.4,"inStock":true,"category":"home-living","subcategory":"home-decor","info":[{"type":"shipping","value":"Egypt"}]},{"id":72,"name":"Yankee Candle Decorative Set","brand":"Yankee Candle","price":49.99,"rating":4.6,"inStock":true,"category":"home-living","subcategory":"home-decor","info":[{"type":"discount","value":"$10","text":"with this deal"}]},{"id":73,"name":"KitchenAid Stand Mixer","brand":"KitchenAid","price":399.99,"rating":4.8,"inStock":true,"category":"home-living","subcategory":"kitchen-dining","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":74,"name":"Ninja Air Fryer","brand":"Ninja","price":129.99,"rating":4.7,"inStock":true,"category":"home-living","subcategory":"kitchen-dining","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":75,"name":"IKEA Premium Duvet Set","brand":"IKEA","price":79.99,"rating":4.5,"inStock":true,"category":"home-living","subcategory":"bedding","info":[{"type":"shipping","value":"Egypt"}]},{"id":76,"name":"TOTO Modern Bathroom Set","brand":"TOTO","price":299.99,"rating":4.6,"inStock":true,"category":"home-living","subcategory":"bath","info":[{"type":"badge","value":"Limited Offer"},{"type":"shipping","value":"Egypt"}]},{"id":77,"name":"Philips Hue Smart Lamp","brand":"Philips","price":99.99,"rating":4.7,"inStock":true,"category":"home-living","subcategory":"lighting","info":[{"type":"badge","value":"Best Seller"}]},{"id":78,"name":"IKEA Floor Lamp","brand":"IKEA","price":59.99,"rating":4.4,"inStock":true,"category":"home-living","subcategory":"lighting","info":[{"type":"discount","value":"10%","text":"today"},{"type":"shipping","value":"Egypt"}]},{"id":79,"name":"IKEA Storage Cabinet","brand":"IKEA","price":149.99,"rating":4.5,"inStock":true,"category":"home-living","subcategory":"storage-organization","info":[{"type":"shipping","value":"Egypt"}]},{"id":80,"name":"Dyson V15 Detect","brand":"Dyson","price":749.99,"rating":4.8,"inStock":true,"category":"home-living","subcategory":"home-appliances","info":[{"type":"badge","value":"Best Seller"},{"type":"discount","value":"$50","text":"with this deal"}]},{"id":81,"name":"Philips Air Purifier","brand":"Philips","price":249.99,"rating":4.6,"inStock":true,"category":"home-living","subcategory":"home-appliances","info":[{"type":"discount","value":"10%","text":"today"},{"type":"shipping","value":"Egypt"}]},{"id":82,"name":"CeraVe Hydrating Cleanser","brand":"CeraVe","price":19.99,"rating":4.7,"inStock":true,"category":"beauty","subcategory":"skincare","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":83,"name":"The Ordinary Niacinamide Serum","brand":"The Ordinary","price":12.99,"rating":4.6,"inStock":true,"category":"beauty","subcategory":"skincare","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":84,"name":"Maybelline Fit Me Foundation","brand":"Maybelline","price":14.99,"rating":4.5,"inStock":true,"category":"beauty","subcategory":"makeup","info":[{"type":"badge","value":"Best Seller"}]},{"id":85,"name":"L'Oréal True Match Foundation","brand":"L'Oréal","price":16.99,"rating":4.6,"inStock":true,"category":"beauty","subcategory":"makeup","info":[{"type":"discount","value":"$3","text":"with this deal"},{"type":"shipping","value":"Egypt"}]},{"id":86,"name":"Olaplex No.4 Shampoo","brand":"Olaplex","price":30.99,"rating":4.7,"inStock":true,"category":"beauty","subcategory":"hair-care","info":[{"type":"badge","value":"Limited Offer"},{"type":"shipping","value":"Egypt"}]},{"id":87,"name":"Pantene Pro-V Shampoo","brand":"Pantene","price":9.99,"rating":4.4,"inStock":true,"category":"beauty","subcategory":"hair-care","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":88,"name":"Dior Sauvage Eau de Toilette","brand":"Dior","price":119.99,"rating":4.8,"inStock":true,"category":"beauty","subcategory":"fragrances","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":89,"name":"Chanel Coco Mademoiselle","brand":"Chanel","price":149.99,"rating":4.8,"inStock":true,"category":"beauty","subcategory":"fragrances","info":[{"type":"discount","value":"10%","text":"today"},{"type":"badge","value":"Limited Offer"}]},{"id":90,"name":"Philips OneBlade","brand":"Philips","price":49.99,"rating":4.6,"inStock":true,"category":"beauty","subcategory":"personal-care","info":[{"type":"shipping","value":"Egypt"}]},{"id":91,"name":"Gillette Fusion5 Razor","brand":"Gillette","price":24.99,"rating":4.5,"inStock":true,"category":"beauty","subcategory":"mens-grooming","info":[{"type":"badge","value":"Best Seller"}]},{"id":92,"name":"Braun Series 9 Pro","brand":"Braun","price":299.99,"rating":4.7,"inStock":true,"category":"beauty","subcategory":"mens-grooming","info":[{"type":"discount","value":"$30","text":"with this deal"},{"type":"shipping","value":"Egypt"}]},{"id":93,"name":"Dyson Airwrap","brand":"Dyson","price":599.99,"rating":4.8,"inStock":true,"category":"beauty","subcategory":"beauty-tools","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":94,"name":"Nike Training Mat","brand":"Nike","price":49.99,"rating":4.5,"inStock":true,"category":"sports","subcategory":"exercise-fitness","info":[{"type":"discount","value":"10%","text":"today"},{"type":"shipping","value":"Egypt"}]},{"id":95,"name":"Bowflex Adjustable Dumbbells","brand":"Bowflex","price":399.99,"rating":4.7,"inStock":true,"category":"sports","subcategory":"exercise-fitness","info":[{"type":"badge","value":"Best Seller"}]},{"id":96,"name":"Nike Pegasus 41","brand":"Nike","price":139.99,"rating":4.8,"inStock":true,"category":"sports","subcategory":"running","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":97,"name":"Adidas Adizero Running Shoes","brand":"Adidas","price":149.99,"rating":4.7,"inStock":true,"category":"sports","subcategory":"running","info":[{"type":"discount","value":"$20","text":"with this deal"}]},{"id":98,"name":"Adidas Predator Football Boots","brand":"Adidas","price":199.99,"rating":4.8,"inStock":true,"category":"sports","subcategory":"football","info":[{"type":"badge","value":"Limited Offer"},{"type":"shipping","value":"Egypt"}]},{"id":99,"name":"Nike Academy Football","brand":"Nike","price":34.99,"rating":4.6,"inStock":true,"category":"sports","subcategory":"football","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":100,"name":"Nike LeBron Basketball Shoes","brand":"Nike","price":199.99,"rating":4.8,"inStock":true,"category":"sports","subcategory":"basketball","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":101,"name":"Spalding NBA Basketball","brand":"Spalding","price":39.99,"rating":4.6,"inStock":true,"category":"sports","subcategory":"basketball","info":[{"type":"discount","value":"$5","text":"with this deal"}]},{"id":102,"name":"Trek Marlin Mountain Bike","brand":"Trek","price":899.99,"rating":4.7,"inStock":true,"category":"sports","subcategory":"cycling","info":[{"type":"badge","value":"Limited Offer"},{"type":"shipping","value":"Egypt"}]},{"id":103,"name":"Giro Cycling Helmet","brand":"Giro","price":89.99,"rating":4.6,"inStock":true,"category":"sports","subcategory":"cycling","info":[{"type":"badge","value":"Best Seller"}]},{"id":104,"name":"Coleman 4-Person Tent","brand":"Coleman","price":129.99,"rating":4.6,"inStock":true,"category":"sports","subcategory":"camping-hiking","info":[{"type":"discount","value":"10%","text":"today"},{"type":"shipping","value":"Egypt"}]},{"id":105,"name":"The North Face Hiking Backpack","brand":"The North Face","price":149.99,"rating":4.7,"inStock":true,"category":"sports","subcategory":"camping-hiking","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":106,"name":"Coleman Portable Grill","brand":"Coleman","price":99.99,"rating":4.5,"inStock":true,"category":"sports","subcategory":"outdoor-recreation","info":[{"type":"discount","value":"$15","text":"with this deal"}]},{"id":107,"name":"Nike Sports Water Bottle","brand":"Nike","price":24.99,"rating":4.4,"inStock":true,"category":"sports","subcategory":"sports-accessories","info":[{"type":"shipping","value":"Egypt"}]},{"id":108,"name":"PlayStation 5 Slim","brand":"Sony","price":499.99,"rating":4.8,"inStock":true,"category":"gaming","subcategory":"gaming-consoles","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":109,"name":"Xbox Series X","brand":"Microsoft","price":499.99,"rating":4.7,"inStock":true,"category":"gaming","subcategory":"gaming-consoles","info":[{"type":"discount","value":"$20","text":"with this deal"}]},{"id":110,"name":"Nintendo Switch OLED","brand":"Nintendo","price":349.99,"rating":4.8,"inStock":true,"category":"gaming","subcategory":"gaming-consoles","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":111,"name":"EA Sports FC 25","brand":"EA","price":69.99,"rating":4.5,"inStock":true,"category":"gaming","subcategory":"video-games","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":112,"name":"Call of Duty Black Ops 6","brand":"Activision","price":69.99,"rating":4.6,"inStock":true,"category":"gaming","subcategory":"video-games","info":[{"type":"badge","value":"Best Seller"}]},{"id":113,"name":"Sony DualSense Wireless Controller","brand":"Sony","price":69.99,"rating":4.8,"inStock":true,"category":"gaming","subcategory":"gaming-controllers","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":114,"name":"Xbox Wireless Controller","brand":"Microsoft","price":59.99,"rating":4.7,"inStock":true,"category":"gaming","subcategory":"gaming-controllers","info":[{"type":"discount","value":"$10","text":"with this deal"}]},{"id":115,"name":"SteelSeries Arctis Nova Pro","brand":"SteelSeries","price":349.99,"rating":4.7,"inStock":true,"category":"gaming","subcategory":"gaming-headsets","info":[{"type":"badge","value":"Limited Offer"},{"type":"shipping","value":"Egypt"}]},{"id":116,"name":"Razer BlackShark V2","brand":"Razer","price":129.99,"rating":4.6,"inStock":true,"category":"gaming","subcategory":"gaming-headsets","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":117,"name":"Razer BlackWidow V4","brand":"Razer","price":169.99,"rating":4.7,"inStock":true,"category":"gaming","subcategory":"gaming-keyboards-mice","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":118,"name":"Logitech G Pro X Superlight","brand":"Logitech","price":159.99,"rating":4.8,"inStock":true,"category":"gaming","subcategory":"gaming-keyboards-mice","info":[{"type":"discount","value":"$20","text":"with this deal"}]},{"id":119,"name":"ASUS ROG Swift Gaming Monitor","brand":"ASUS","price":699.99,"rating":4.7,"inStock":true,"category":"gaming","subcategory":"gaming-monitors","info":[{"type":"badge","value":"Limited Offer"},{"type":"shipping","value":"Egypt"}]},{"id":120,"name":"Alienware 27 Gaming Monitor","brand":"Alienware","price":799.99,"rating":4.8,"inStock":true,"category":"gaming","subcategory":"gaming-monitors","info":[{"type":"badge","value":"Best Seller"}]},{"id":121,"name":"Secretlab TITAN Evo","brand":"Secretlab","price":499.99,"rating":4.8,"inStock":true,"category":"gaming","subcategory":"gaming-chairs","info":[{"type":"discount","value":"10%","text":"today"},{"type":"shipping","value":"Egypt"}]},{"id":122,"name":"Razer Iskur V2","brand":"Razer","price":599.99,"rating":4.7,"inStock":true,"category":"gaming","subcategory":"gaming-chairs","info":[{"type":"badge","value":"Limited Offer"}]},{"id":123,"name":"Elgato Stream Deck","brand":"Elgato","price":149.99,"rating":4.7,"inStock":true,"category":"gaming","subcategory":"gaming-accessories","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":124,"name":"LEGO Classic Creative Box","brand":"LEGO","price":39.99,"rating":4.8,"inStock":true,"category":"toys-kids","subcategory":"toys","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":125,"name":"Hot Wheels Track Set","brand":"Hot Wheels","price":29.99,"rating":4.7,"inStock":true,"category":"toys-kids","subcategory":"toys","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":126,"name":"Marvel Spider-Man Figure","brand":"Marvel","price":24.99,"rating":4.6,"inStock":true,"category":"toys-kids","subcategory":"action-figures","info":[{"type":"badge","value":"Best Seller"}]},{"id":127,"name":"Star Wars Action Figure","brand":"Star Wars","price":29.99,"rating":4.7,"inStock":true,"category":"toys-kids","subcategory":"action-figures","info":[{"type":"discount","value":"$5","text":"with this deal"},{"type":"shipping","value":"Egypt"}]},{"id":128,"name":"Barbie Dreamhouse","brand":"Barbie","price":199.99,"rating":4.8,"inStock":true,"category":"toys-kids","subcategory":"dolls-accessories","info":[{"type":"badge","value":"Limited Offer"},{"type":"shipping","value":"Egypt"}]},{"id":129,"name":"Disney Princess Doll","brand":"Disney","price":34.99,"rating":4.6,"inStock":true,"category":"toys-kids","subcategory":"dolls-accessories","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":130,"name":"LEGO City Police Station","brand":"LEGO","price":99.99,"rating":4.9,"inStock":true,"category":"toys-kids","subcategory":"building-construction","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":131,"name":"Mega Bloks Building Set","brand":"Mega Bloks","price":39.99,"rating":4.6,"inStock":true,"category":"toys-kids","subcategory":"building-construction","info":[{"type":"discount","value":"$5","text":"with this deal"}]},{"id":132,"name":"VTech Learning Tablet","brand":"VTech","price":49.99,"rating":4.5,"inStock":true,"category":"toys-kids","subcategory":"educational-toys","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]},{"id":133,"name":"Melissa & Doug Puzzle Set","brand":"Melissa & Doug","price":24.99,"rating":4.7,"inStock":true,"category":"toys-kids","subcategory":"educational-toys","info":[{"type":"discount","value":"10%","text":"today"}]},{"id":134,"name":"Little Tikes Outdoor Slide","brand":"Little Tikes","price":149.99,"rating":4.7,"inStock":true,"category":"toys-kids","subcategory":"outdoor-toys","info":[{"type":"badge","value":"Limited Offer"},{"type":"shipping","value":"Egypt"}]},{"id":135,"name":"Fisher-Price Baby Rocker","brand":"Fisher-Price","price":89.99,"rating":4.7,"inStock":true,"category":"toys-kids","subcategory":"baby-products","info":[{"type":"badge","value":"Best Seller"}]},{"id":136,"name":"Philips Avent Baby Bottle Set","brand":"Philips Avent","price":34.99,"rating":4.7,"inStock":true,"category":"toys-kids","subcategory":"baby-products","info":[{"type":"discount","value":"10%","text":"today"},{"type":"shipping","value":"Egypt"}]},{"id":137,"name":"Skip Hop Kids Backpack","brand":"Skip Hop","price":39.99,"rating":4.5,"inStock":true,"category":"toys-kids","subcategory":"kids-accessories","info":[{"type":"badge","value":"Best Seller"},{"type":"shipping","value":"Egypt"}]}];
