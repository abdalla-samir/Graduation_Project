const fs = require("fs");
const path = require("path");

const root = __dirname;
const out = path.join(root, "wwwroot", "source");

const files = [
  ["controrllers/Authcontroller.cs", "AuthController.cs"],
  ["controrllers/Accountcontroller.cs", "AccountController.cs"],
  ["controrllers/Inboxcontroller.cs", "InboxController.cs"],
  ["data/sessiondata.cs", "SessionData.cs"],
  ["Program.cs", "Program.cs"]
];

fs.mkdirSync(out, { recursive: true });

files.forEach(function (pair) {
  var text = fs.readFileSync(path.join(root, pair[0]), "utf8").replace(/^﻿/, "").replace(/\r\n/g, "\n");
  text = text
    .split("\n")
    .filter(function (line) {
      return !/Intentionally vulnerable/i.test(line);
    })
    .join("\n")
    .replace(/LAB\{[^}]*\}/g, "LAB{...}");
  fs.writeFileSync(path.join(out, pair[1] + ".txt"), text);
});

console.log("source files written to wwwroot/source");
