﻿using System.Security.Cryptography;
using Microsoft.AspNetCore.Mvc;
using TwoFactorBypassLab.Data;

namespace TwoFactorBypassLab.Controllers;

[ApiController]
[Route("auth")]
public class AuthController : ControllerBase
{
    private readonly LabData _users;
    private readonly SessionData _sessions;

    public AuthController(LabData users, SessionData sessions)
    {
        _users = users;
        _sessions = sessions;
    }

    [HttpPost("login")]
    public IActionResult Login(
        [FromForm] string username,
        [FromForm] string password)
    {
        var user = _users.Users.FirstOrDefault(u =>
            u.Username == username &&
            u.Password == password);

        if (user == null)
            return Unauthorized("Invalid credentials.");

        var session = new LoginSession
        {
            SessionId = Guid.NewGuid().ToString("N"),
            UserId = user.Id,
            MfaVerified = false,
            OtpCode = RandomNumberGenerator
                .GetInt32(100000, 1000000).ToString(),
            OtpExpiresAt = DateTime.UtcNow.AddMinutes(5)
        };

        lock (_sessions.Sessions)
            _sessions.Sessions.Add(session);

        var options = new CookieOptions
        {
            HttpOnly = true,
            SameSite = SameSiteMode.Lax,
            Secure = Request.IsHttps
        };

        Response.Cookies.Append(
            "session_id", session.SessionId, options);

        Response.Cookies.Append(
            "auth_pending", "true", options);

        return Ok(new
        {
            Message = "Password accepted. 2FA required.",
            Next = "/auth/verify"
        });
    }

    [HttpPost("verify")]
    public IActionResult Verify([FromForm] string code)
    {
        var session = GetSession();

        if (session == null)
            return Unauthorized();

        if (session.MfaVerified)
            return Ok("Already verified.");

        if (DateTime.UtcNow >= session.OtpExpiresAt)
            return BadRequest("OTP expired.");

        if (session.OtpCode != code)
            return BadRequest("Invalid OTP.");

        lock (_sessions.Sessions)
        {
            session.MfaVerified = true;
            session.OtpCode = "";
        }

        Response.Cookies.Delete("auth_pending");

        return Ok(new
        {
            Message = "2FA completed successfully.",
            Next = "/account"
        });
    }

    [HttpPost("resend")]
    public IActionResult Resend()
    {
        var session = GetSession();

        if (session == null)
            return Unauthorized();

        if (session.MfaVerified)
            return BadRequest("Already verified.");

        lock (_sessions.Sessions)
        {
            session.OtpCode = RandomNumberGenerator
                .GetInt32(100000, 1000000).ToString();
            session.OtpExpiresAt = DateTime.UtcNow.AddMinutes(5);
        }

        return Ok(new
        {
            Message = "A new code was sent."
        });
    }

    [HttpPost("logout")]
    public IActionResult Logout()
    {
        var session = GetSession();

        if (session != null)
        {
            lock (_sessions.Sessions)
                _sessions.Sessions.Remove(session);
        }

        Response.Cookies.Delete("session_id");
        Response.Cookies.Delete("auth_pending");

        return Ok("Logged out successfully.");
    }

    private LoginSession? GetSession()
    {
        if (!Request.Cookies.TryGetValue(
            "session_id", out var id))
            return null;

        lock (_sessions.Sessions)
            return _sessions.Sessions
                .FirstOrDefault(s => s.SessionId == id);
    }
}