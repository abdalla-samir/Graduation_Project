﻿using Microsoft.AspNetCore.Mvc;
using TwoFactorBypassLab.Data;

namespace TwoFactorBypassLab.Controllers;

[ApiController]
[Route("inbox")]
public class InboxController : ControllerBase
{
    private readonly SessionData _sessions;
    private readonly LabData _users;

    public InboxController(
        SessionData sessions,
        LabData users)
    {
        _sessions = sessions;
        _users = users;
    }

    [HttpGet("player")]
    public IActionResult PlayerInbox()
    {
        var player = _users.Users.First(
            u => u.Username == "player");

        var session = _sessions.Sessions
            .LastOrDefault(s =>
                s.UserId == player.Id &&
                !s.MfaVerified &&
                s.OtpExpiresAt > DateTime.UtcNow);

        if (session == null)
            return Ok("No active verification email.");

        return Ok(new
        {
            To = "player@lab.test",
            Subject = "Your verification code",
            Code = session.OtpCode
        });
    }
}