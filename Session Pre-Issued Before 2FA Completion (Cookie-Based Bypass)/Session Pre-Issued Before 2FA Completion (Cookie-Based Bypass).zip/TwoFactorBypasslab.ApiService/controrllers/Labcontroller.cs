using Microsoft.AspNetCore.Mvc;

namespace TwoFactorBypassLab.Controllers;

[ApiController]
[Route("lab")]
public class LabController : ControllerBase
{
    private const string Flag = "LAB{TWO_FACTOR_SESSION_SECURITY}";

    [HttpPost("check-flag")]
    public IActionResult CheckFlag([FromForm] string flag)
    {
        var solved = string.Equals(
            flag?.Trim(), Flag, StringComparison.Ordinal);

        return Ok(new
        {
            Solved = solved,
            Message = solved
                ? "Challenge solved."
                : "That is not the flag."
        });
    }
}
