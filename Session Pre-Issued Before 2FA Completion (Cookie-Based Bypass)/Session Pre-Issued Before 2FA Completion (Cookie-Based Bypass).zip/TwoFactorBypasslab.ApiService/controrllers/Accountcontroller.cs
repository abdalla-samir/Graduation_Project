﻿using Microsoft.AspNetCore.Mvc;
using TwoFactorBypassLab.Data;

namespace TwoFactorBypassLab.Controllers;

[ApiController]
[Route("account")]
public class AccountController : ControllerBase
{
    private readonly LabData _users;
    private readonly SessionData _sessions;

    public AccountController(LabData users, SessionData sessions)
    {
        _users = users;
        _sessions = sessions;
    }

    [HttpGet]
    public IActionResult MyAccount()
    {
        if (!Request.Cookies.TryGetValue(
            "session_id", out var sessionId))
            return Unauthorized("Login required.");

        LoginSession? session;

        lock (_sessions.Sessions)
        {
            session = _sessions.Sessions.FirstOrDefault(
                s => s.SessionId == sessionId);
        }

        if (session == null)
            return Unauthorized("Invalid session.");

        // Intentionally vulnerable lab logic
        if (Request.Cookies.ContainsKey("auth_pending"))
            return StatusCode(403, new
            {
                Message = "2FA verification required.",
                Next = "/auth/verify"
            });

        var user = _users.Users.FirstOrDefault(
            u => u.Id == session.UserId);

        if (user == null)
            return Unauthorized();

        return Ok(new
        {
            user.Username,
            Message = "Welcome to My Account",
            Flag = user.Username == "omar"
                ? "LAB{TWO_FACTOR_SESSION_SECURITY}"
                : null
        });
    }

    [HttpGet("security")]
    public IActionResult Security()
    {
        if (!Request.Cookies.TryGetValue(
            "session_id", out var sessionId))
            return Unauthorized("Login required.");

        LoginSession? session;

        lock (_sessions.Sessions)
        {
            session = _sessions.Sessions.FirstOrDefault(
                s => s.SessionId == sessionId);
        }

        if (session == null)
            return Unauthorized("Invalid session.");

        if (Request.Cookies.ContainsKey("auth_pending"))
            return StatusCode(403, new
            {
                Message = "2FA verification required.",
                Next = "/auth/verify"
            });

        var user = _users.Users.FirstOrDefault(
            u => u.Id == session.UserId);

        if (user == null)
            return Unauthorized();

        return Ok(new
        {
            user.Username,
            user.TwoFactorEnabled,
            Method = "Email"
        });
    }
}
