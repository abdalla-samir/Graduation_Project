﻿namespace ResponseManipulationLab.Data;

public class LabUser
{
    public int Id { get; set; }
    public string Username { get; set; } = "";
    public string Password { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string StudentId { get; set; } = "";
    public string Email { get; set; } = "";
}

public class LabData
{
    public List<LabUser> Users { get; } = new()
    {
        new LabUser
        {
            Id = 1,
            Username = "mariam",
            Password = "Lab@1234",
            DisplayName = "Mariam",
            StudentId = "AU2026014",
            Email = "mariam@aurelia.lab.test"
        },
        new LabUser
        {
            Id = 2,
            Username = "player",
            Password = "Player123!",
            DisplayName = "Player",
            StudentId = "AU2026099",
            Email = "player@aurelia.lab.test"
        }
    };
}