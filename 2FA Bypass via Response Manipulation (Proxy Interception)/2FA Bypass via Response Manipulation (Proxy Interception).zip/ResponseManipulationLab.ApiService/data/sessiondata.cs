﻿namespace ResponseManipulationLab.Data;

public class LoginSession
{
    public string SessionId { get; set; } = "";
    public int UserId { get; set; }
    public bool MfaVerified { get; set; }
    public DateTime ExpiresAt { get; set; }
}

public class SessionData
{
    public List<LoginSession> Sessions { get; } = new();
}