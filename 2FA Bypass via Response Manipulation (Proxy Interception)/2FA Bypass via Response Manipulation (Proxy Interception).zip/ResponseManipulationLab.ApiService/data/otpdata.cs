﻿namespace ResponseManipulationLab.Data;

public class OtpRecord
{
    public string SessionId { get; set; } = "";
    public string Code { get; set; } = "";
    public DateTime ExpiresAt { get; set; }
    public bool Used { get; set; }
    public int FailedAttempts { get; set; }
}

public class OtpData
{
    public List<OtpRecord> Records { get; } = new();
}