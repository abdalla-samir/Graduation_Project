﻿using Microsoft.AspNetCore.Mvc;

namespace ResponseManipulationLab.Controllers;

[ApiController]
[Route("lab/access")]
public class LabAccessController : ControllerBase
{
    // Intentionally vulnerable authorization logic.
    // Training-only endpoint with synthetic data.

    [HttpGet("training-dashboard")]
    public IActionResult TrainingDashboard(
        [FromQuery] int clientStatus = 3)
    {
        // BUG: Trusting a client-controlled status.
        if (clientStatus != 1)
        {
            return StatusCode(403, new
            {
                Message = "Access denied"
            });
        }

        // This is an actual access decision,
        // not a simulated boolean result.
        return Ok(new
        {
            Message = "Training dashboard access granted",
            Account = "Demo Student",
            Resource = "Synthetic training content"
        });
    }
}