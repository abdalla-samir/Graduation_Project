﻿using Microsoft.AspNetCore.Mvc;
using ResponseManipulationLab.Data;

namespace ResponseManipulationLab.Controllers;

[ApiController]
[Route("dashboard")]
public class DashboardController : ControllerBase
{
    private readonly LabData _users;
    private readonly SessionData _sessions;

    public DashboardController(
        LabData users,
        SessionData sessions)
    {
        _users = users;
        _sessions = sessions;
    }

    [HttpGet]
    public IActionResult GetDashboard()
    {
        var session = GetSession();

        if (session == null)
            return Unauthorized("Login required.");

        if (Request.Cookies["mfa_passed"] != "true")
        {
            return StatusCode(403, new
            {
                Message = "2FA verification required.",
                Next = "/2fa/verify"
            });
        }

        var user = _users.Users.FirstOrDefault(
            u => u.Id == session.UserId);

        if (user == null)
            return NotFound();

        return Ok(new
        {
            Message = "Welcome to Student Dashboard",
            user.DisplayName,
            user.Username,
            user.StudentId,
            user.Email,
            Flag = user.Username == "mariam"
                ? "LAB{RESPONSE_MANIPULATION_DEMO}"
                : null
        });
    }

    [HttpGet("security")]
    public IActionResult Security()
    {
        var session = GetSession();

        if (session == null)
            return Unauthorized("Login required.");

        if (Request.Cookies["mfa_passed"] != "true")
        {
            return StatusCode(403, new
            {
                Message = "2FA verification required.",
                Next = "/2fa/verify"
            });
        }

        var user = _users.Users.FirstOrDefault(
            u => u.Id == session.UserId);

        if (user == null)
            return NotFound();

        return Ok(new
        {
            user.Username,
            TwoFactorEnabled = true,
            Method = "Email"
        });
    }

    [HttpGet("lab/compare")]
    public IActionResult Compare(
        [FromQuery] int responseStatus = 3)
    {
        var session = GetSession();

        if (session == null)
            return Unauthorized("Login required.");

        bool clientTrustedResponse = responseStatus == 1;
        bool serverVerifiedMfa = session.MfaVerified;

        return Ok(new
        {
            ReceivedStatus = responseStatus,
            ClientWouldAllow = clientTrustedResponse,
            ServerWouldAllow = serverVerifiedMfa,
            VulnerableDecision =
                clientTrustedResponse && !serverVerifiedMfa,
            Explanation =
                clientTrustedResponse && !serverVerifiedMfa
                ? "A client-controlled status would incorrectly grant access."
                : "The server checks its own MFA verification state."
        });
    }

    private LoginSession? GetSession()
    {
        if (!Request.Cookies.TryGetValue(
            "lab_session", out var sessionId))
            return null;

        lock (_sessions.Sessions)
        {
            return _sessions.Sessions.FirstOrDefault(s =>
                s.SessionId == sessionId &&
                s.ExpiresAt > DateTime.UtcNow);
        }
    }
}
