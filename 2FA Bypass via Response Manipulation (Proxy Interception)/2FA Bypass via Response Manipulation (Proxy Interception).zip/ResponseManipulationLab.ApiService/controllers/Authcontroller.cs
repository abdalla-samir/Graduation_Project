﻿using System.Security.Cryptography;
using Microsoft.AspNetCore.Mvc;
using ResponseManipulationLab.Data;

namespace ResponseManipulationLab.Controllers;

[ApiController]
[Route("auth")]
public class AuthController : ControllerBase
{
    private readonly LabData _users;
    private readonly SessionData _sessions;
    private readonly OtpData _otps;

    public AuthController(
        LabData users,
        SessionData sessions,
        OtpData otps)
    {
        _users = users;
        _sessions = sessions;
        _otps = otps;
    }

    [HttpPost("login")]
    public IActionResult Login(
        [FromForm] string username,
        [FromForm] string password)
    {
        var user = _users.Users.FirstOrDefault(u =>
            u.Username == username &&
            u.Password == password);

        if (user == null)
            return Unauthorized(new
            {
                status = 3,
                message = "Invalid credentials"
            });

        var session = new LoginSession
        {
            SessionId = Guid.NewGuid().ToString("N"),
            UserId = user.Id,
            MfaVerified = false,
            ExpiresAt = DateTime.UtcNow.AddMinutes(15)
        };

        var otp = new OtpRecord
        {
            SessionId = session.SessionId,
            Code = RandomNumberGenerator
                .GetInt32(100000, 1000000).ToString(),
            ExpiresAt = DateTime.UtcNow.AddMinutes(5)
        };

        lock (_sessions.Sessions)
            _sessions.Sessions.Add(session);

        lock (_otps.Records)
            _otps.Records.Add(otp);

        Response.Cookies.Delete("mfa_passed");

        Response.Cookies.Append(
            "lab_session",
            session.SessionId,
            new CookieOptions
            {
                HttpOnly = true,
                SameSite = SameSiteMode.Lax,
                Secure = Request.IsHttps
            });

        return Ok(new
        {
            status = 1,
            message = "Password accepted. OTP required.",
            next = "/2fa/verify"
        });
    }

    [HttpPost("/2fa/verify")]
    public IActionResult Verify(
        [FromBody] VerifyOtpRequest request)
    {
        var session = GetSession();

        if (session == null)
            return Unauthorized(new
            {
                status = 3,
                message = "Invalid session"
            });

        lock (_otps.Records)
        {
            var otp = _otps.Records.FirstOrDefault(o =>
                o.SessionId == session.SessionId);

            if (otp == null ||
                otp.Used ||
                DateTime.UtcNow >= otp.ExpiresAt ||
                otp.FailedAttempts >= 5)
            {
                return Ok(new
                {
                    status = 3,
                    message = "OTP unavailable"
                });
            }

            if (otp.Code != request.Code)
            {
                otp.FailedAttempts++;

                return Ok(new
                {
                    status = 3,
                    message = "Invalid OTP"
                });
            }

            otp.Used = true;

            return Ok(new
            {
                status = 1,
                message = "OTP verified successfully",
                next = "/dashboard"
            });
        }
    }

    [HttpPost("resend")]
    public IActionResult Resend()
    {
        var session = GetSession();

        if (session == null)
            return Unauthorized(new
            {
                status = 3,
                message = "Invalid session"
            });

        lock (_otps.Records)
        {
            var otp = _otps.Records.FirstOrDefault(o =>
                o.SessionId == session.SessionId);

            if (otp == null)
            {
                otp = new OtpRecord { SessionId = session.SessionId };
                _otps.Records.Add(otp);
            }

            otp.Code = RandomNumberGenerator
                .GetInt32(100000, 1000000).ToString();
            otp.ExpiresAt = DateTime.UtcNow.AddMinutes(5);
            otp.Used = false;
        }

        return Ok(new
        {
            status = 1,
            message = "A new code was sent."
        });
    }

    [HttpPost("lab/response-demo")]
    public IActionResult ResponseDemo(
        [FromBody] ResponseDemoRequest request)
    {
        const int actualStatus = 3;

        int browserStatus = request.ModifiedStatus;

        return Ok(new
        {
            ActualServerStatus = actualStatus,
            BrowserReceivedStatus = browserStatus,
            FrontendWouldNavigate = browserStatus == 1,
            ServerMfaVerified = false,
            SecurityIssue = browserStatus == 1
                ? "Frontend trusted a manipulated response."
                : "Frontend rejected the invalid OTP."
        });
    }

    [HttpPost("logout")]
    public IActionResult Logout()
    {
        var session = GetSession();

        if (session != null)
        {
            lock (_sessions.Sessions)
                _sessions.Sessions.Remove(session);
        }

        Response.Cookies.Delete("lab_session");
        Response.Cookies.Delete("mfa_passed");

        return Ok(new
        {
            message = "Logged out"
        });
    }

    private LoginSession? GetSession()
    {
        if (!Request.Cookies.TryGetValue(
            "lab_session", out var sessionId))
            return null;

        lock (_sessions.Sessions)
        {
            return _sessions.Sessions.FirstOrDefault(s =>
                s.SessionId == sessionId &&
                s.ExpiresAt > DateTime.UtcNow);
        }
    }
}

public class VerifyOtpRequest
{
    public string Code { get; set; } = "";
}

public class ResponseDemoRequest
{
    public int ModifiedStatus { get; set; }
}