using Microsoft.AspNetCore.Mvc;
using ResponseManipulationLab.Data;

namespace ResponseManipulationLab.Controllers;

[ApiController]
[Route("inbox")]
public class InboxController : ControllerBase
{
    private readonly LabData _users;
    private readonly SessionData _sessions;
    private readonly OtpData _otps;

    public InboxController(
        LabData users,
        SessionData sessions,
        OtpData otps)
    {
        _users = users;
        _sessions = sessions;
        _otps = otps;
    }

    [HttpGet("player")]
    public IActionResult PlayerInbox()
    {
        var player = _users.Users.First(
            u => u.Username == "player");

        lock (_otps.Records)
        {
            var otp = _otps.Records.LastOrDefault(o =>
                !o.Used &&
                o.ExpiresAt > DateTime.UtcNow &&
                _sessions.Sessions.Any(s =>
                    s.SessionId == o.SessionId &&
                    s.UserId == player.Id));

            if (otp == null)
                return Ok("No active verification email.");

            return Ok(new
            {
                To = player.Email,
                Subject = "Your verification code",
                Code = otp.Code
            });
        }
    }
}
