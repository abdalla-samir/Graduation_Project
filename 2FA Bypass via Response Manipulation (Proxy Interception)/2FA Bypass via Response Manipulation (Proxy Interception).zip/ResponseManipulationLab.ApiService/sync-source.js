const fs = require("fs");
const path = require("path");

const root = __dirname;
const out = path.join(root, "wwwroot", "source");

const files = [
  ["controllers/Authcontroller.cs", "AuthController.cs"],
  ["controllers/dashboardcontroller.cs", "DashboardController.cs"],
  ["controllers/Inboxcontroller.cs", "InboxController.cs"],
  ["data/sessiondata.cs", "SessionData.cs"],
  ["data/otpdata.cs", "OtpData.cs"],
  ["Program.cs", "Program.cs"]
];

fs.mkdirSync(out, { recursive: true });

files.forEach(function (pair) {
  var text = fs.readFileSync(path.join(root, pair[0]), "utf8").replace(/^﻿/, "").replace(/\r\n/g, "\n");
  text = text
    .split("\n")
    .filter(function (line) {
      return !/Intentionally vulnerable|\/\/\s*BUG/i.test(line);
    })
    .join("\n")
    .replace(/LAB\{[^}]*\}/g, "LAB{...}");
  fs.writeFileSync(path.join(out, pair[1] + ".txt"), text);
});

console.log("source files written to wwwroot/source");
