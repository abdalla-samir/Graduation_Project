using ResponseManipulationLab.Data;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

builder.Services.AddSingleton<LabData>();
builder.Services.AddSingleton<SessionData>();
builder.Services.AddSingleton<OtpData>();

var app = builder.Build();

app.UseHttpsRedirection();

app.UseDefaultFiles();
app.UseStaticFiles();

app.MapControllers();

app.Run();
