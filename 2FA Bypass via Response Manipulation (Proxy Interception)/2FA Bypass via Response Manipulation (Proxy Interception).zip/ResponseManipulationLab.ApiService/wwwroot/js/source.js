var SOURCE_FILES = [
  { name: "AuthController.cs", url: "./source/AuthController.cs.txt" },
  { name: "DashboardController.cs", url: "./source/DashboardController.cs.txt" },
  { name: "InboxController.cs", url: "./source/InboxController.cs.txt" },
  { name: "SessionData.cs", url: "./source/SessionData.cs.txt" },
  { name: "OtpData.cs", url: "./source/OtpData.cs.txt" },
  { name: "Program.cs", url: "./source/Program.cs.txt" }
];

(function () {
  var modal = document.getElementById("source-modal");
  if (!modal || modal.dataset.ready) return;
  modal.dataset.ready = "1";

  var tabs = document.getElementById("source-tabs");
  var code = document.getElementById("source-code");
  var gutter = document.getElementById("source-gutter");
  var cache = {};
  var buttons = [];

  function setActive(index) {
    buttons.forEach(function (b, i) {
      b.className = "btn w-fit px-3 py-1 text-sm " + (i === index ? "btn-secondary" : "");
    });
  }

  async function show(index) {
    var file = SOURCE_FILES[index];
    setActive(index);

    if (cache[file.url] === undefined) {
      code.textContent = "Loading...";
      gutter.textContent = "";
      try {
        var res = await fetch(file.url);
        cache[file.url] = res.ok ? await res.text() : "Could not load " + file.name + ".";
      } catch (e) {
        cache[file.url] = "Could not load " + file.name + ".";
      }
    }

    var text = cache[file.url];
    var count = text.split("\n").length;
    var numbers = [];
    for (var i = 1; i <= count; i++) numbers.push(i);

    code.textContent = text;
    gutter.textContent = numbers.join("\n");
  }

  SOURCE_FILES.forEach(function (file, i) {
    var b = document.createElement("button");
    b.type = "button";
    b.textContent = file.name;
    b.addEventListener("click", function () {
      show(i);
    });
    tabs.appendChild(b);
    buttons.push(b);
  });

  function open() {
    modal.classList.remove("hidden");
    modal.classList.add("flex");
    show(0);
  }

  function close() {
    modal.classList.add("hidden");
    modal.classList.remove("flex");
  }

  document.addEventListener("click", function (e) {
    if (e.target.closest("[data-source-open]")) {
      if (typeof closeMenus === "function") closeMenus();
      open();
      return;
    }
    if (e.target.closest("[data-source-close]") || e.target === modal) close();
  });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") close();
  });
})();
