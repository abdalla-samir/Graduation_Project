var form = document.getElementById("code-form");
var msg = document.getElementById("msg");
var box = document.getElementById("msg-box");

(async function () {
  var r = await request("/dashboard");
  if (r.ok) {
    location.replace("./dashboard.html");
  } else if (r.status === 401) {
    location.replace("./login.html");
  }
})();

function notify(text, kind) {
  showMsg(msg, text, kind);
  box.classList.remove("hidden");
}

async function verifyCode(code) {
  var res = await request("/2fa/verify", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code: code })
  });

  if (res.status === 401) {
    location.replace("./login.html");
    return;
  }

  var data = res.data;

  if (data.status === 1) {
    document.cookie = "mfa_passed=true; path=/";
    location.href = "./dashboard.html";
  } else {
    notify("Incorrect verification code.", "error");
  }
}

document.getElementById("resend").addEventListener("click", async function () {
  var r = await request("/auth/resend", { method: "POST" });

  if (r.status === 401) {
    location.replace("./login.html");
    return;
  }

  notify(r.ok ? "A new code was sent to your email." : "Could not send a new code.", r.ok ? "ok" : "error");
});

form.addEventListener("submit", function (e) {
  e.preventDefault();
  box.classList.add("hidden");
  verifyCode(document.getElementById("code").value.trim());
});
