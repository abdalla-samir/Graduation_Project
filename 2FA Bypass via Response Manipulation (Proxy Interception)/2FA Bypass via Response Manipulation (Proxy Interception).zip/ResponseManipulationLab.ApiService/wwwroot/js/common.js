var API = {
  me: "/dashboard",
  logout: "/auth/logout",
  flag: "/lab/check-flag",
  login: "./login.html",
  home: "./index.html"
};

var SOLVED_KEY = "lab.solved";

function $(sel, root) {
  return (root || document).querySelector(sel);
}

function $$(sel, root) {
  return Array.prototype.slice.call((root || document).querySelectorAll(sel));
}

async function request(url, opts) {
  var res = await fetch(url, Object.assign({ credentials: "same-origin" }, opts || {}));
  var text = await res.text();
  var data = text;
  try {
    data = JSON.parse(text);
  } catch (e) {}
  return { ok: res.ok, status: res.status, data: data };
}

function postForm(url, fields) {
  return request(url, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(fields)
  });
}

function errorText(r, fallback) {
  if (typeof r.data === "string" && r.data.trim()) return r.data;
  return fallback || "Something went wrong.";
}

function showMsg(el, text, kind) {
  var colors = { error: "text-danger", ok: "text-green-700", warn: "text-cta" };
  el.className = "text-sm " + (colors[kind] || "text-text-secondary");
  el.textContent = text;
}

function storeGet(key) {
  try {
    return localStorage.getItem(key);
  } catch (e) {
    return null;
  }
}

function storeSet(key, value) {
  try {
    localStorage.setItem(key, value);
  } catch (e) {}
}

function setPanel(el, open) {
  var closed = (el.dataset.closed || "").split(" ").filter(Boolean);
  var opened = (el.dataset.opened || "").split(" ").filter(Boolean);
  closed.forEach(function (c) {
    el.classList.toggle(c, !open);
  });
  opened.forEach(function (c) {
    el.classList.toggle(c, open);
  });
}

function closeMenus() {
  $$("[data-panel]").forEach(function (p) {
    setPanel(p, false);
  });
  var overlay = $("#overlay");
  if (overlay) overlay.classList.add("hidden");
}

function openMenu(id) {
  closeMenus();
  var panel = $("#" + id);
  if (!panel) return;
  setPanel(panel, true);
  var overlay = $("#overlay");
  if (overlay) overlay.classList.remove("hidden");
}

function showModal(id) {
  var m = $("#" + id);
  m.classList.remove("hidden");
  m.classList.add("flex");
}

function hideModals() {
  ["flag-modal", "result-modal"].forEach(function (id) {
    var m = $("#" + id);
    if (!m) return;
    m.classList.add("hidden");
    m.classList.remove("flex");
  });
}

function startCountdown() {
  var box = $("#timer");
  if (!box) return;

  function tick() {
    var end = new Date();
    end.setHours(23, 59, 59, 0);
    var diff = Math.max(0, Math.floor((end.getTime() - Date.now()) / 1000));
    var parts = [Math.floor(diff / 3600), Math.floor(diff / 60) % 60, diff % 60];
    $$("[data-time]", box).forEach(function (el, i) {
      el.textContent = String(parts[i]).padStart(2, "0");
    });
  }

  tick();
  setInterval(tick, 1000);
}

function wireShell() {
  document.addEventListener("click", function (e) {
    var open = e.target.closest("[data-menu-open]");
    if (open) {
      openMenu(open.dataset.menuOpen);
      return;
    }
    if (e.target.closest("[data-menu-close]") || e.target.id === "overlay") closeMenus();

    if (e.target.closest("[data-top]")) window.scrollTo({ top: 0, behavior: "smooth" });
  });

  startCountdown();
}

async function initApp(required) {
  wireShell();

  var r = await request(API.me);
  var me = r.ok ? r.data : null;

  if (!me && required) {
    location.replace(API.login);
    return null;
  }

  $$("[data-in]").forEach(function (el) {
    el.hidden = !me;
  });
  $$("[data-out]").forEach(function (el) {
    el.hidden = !!me;
  });

  if (!me) return null;

  $$("[data-user-name]").forEach(function (el) {
    el.textContent = me.name || me.username || me.email;
  });

  var banner = $("#banner");
  if (banner && storeGet(SOLVED_KEY) === "1") banner.classList.remove("hidden");

  $$("[data-logout]").forEach(function (b) {
    b.addEventListener("click", async function () {
      await request(API.logout, { method: "POST" });
      location.href = API.home;
    });
  });

  $$("[data-flag-open]").forEach(function (b) {
    b.addEventListener("click", function () {
      closeMenus();
      $("#flag-input").value = "";
      showModal("flag-modal");
      $("#flag-input").focus();
    });
  });

  $$("[data-modal-close]").forEach(function (b) {
    b.addEventListener("click", hideModals);
  });

  ["flag-modal", "result-modal"].forEach(function (id) {
    var m = $("#" + id);
    if (!m) return;
    m.addEventListener("click", function (e) {
      if (e.target === m) hideModals();
    });
  });

  $("#flag-form").addEventListener("submit", async function (e) {
    e.preventDefault();
    var value = $("#flag-input").value.trim();
    var r2 = await postForm(API.flag, { flag: value });
    var solved = r2.ok && r2.data && r2.data.solved === true;

    var title = $("#result-title");
    var flag = $("#result-flag");

    title.textContent = solved ? "Flag accepted" : "Not solved yet";
    title.className = "text-xl font-bold " + (solved ? "text-green-700" : "text-cta");
    $("#result-text").textContent = solved ? "Challenge solved." : "That is not the flag. Keep looking.";

    if (solved) {
      storeSet(SOLVED_KEY, "1");
      if (banner) banner.classList.remove("hidden");
      flag.textContent = value;
      flag.classList.remove("hidden");
    } else {
      flag.classList.add("hidden");
    }

    hideModals();
    showModal("result-modal");
  });

  return me;
}
