async function portalInit() {
  var r = await request("/dashboard");

  if (r.status === 403) {
    location.replace("./verify.html");
    return null;
  }

  if (!r.ok) {
    location.replace("./login.html");
    return null;
  }

  var u = r.data;

  document.querySelectorAll("[data-fill]").forEach(function (el) {
    var value = u[el.getAttribute("data-fill")];
    if (value !== undefined && value !== null) el.textContent = value;
  });

  await initApp(false);

  var name = u.displayName || u.username || "";
  document.querySelectorAll("[data-user-name]").forEach(function (el) {
    el.textContent = name;
  });
  document.querySelectorAll("[data-initial]").forEach(function (el) {
    el.textContent = name.charAt(0).toUpperCase();
  });

  return u;
}
