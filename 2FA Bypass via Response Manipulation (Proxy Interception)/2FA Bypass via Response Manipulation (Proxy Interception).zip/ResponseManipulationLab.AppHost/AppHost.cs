var builder = DistributedApplication.CreateBuilder(args);

builder.AddDotnetProject("apiservice", "../ResponseManipulationLab.ApiService/ResponseManipulationLab.ApiService.csproj")
    .WithExternalHttpEndpoints()
    .WithHttpHealthCheck("/health");

builder.Build().Run();
